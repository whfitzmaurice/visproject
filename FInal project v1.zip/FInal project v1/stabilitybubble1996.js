

Highcharts.chart('container', {

    chart: {
        type: 'bubble',
        plotBorderWidth: 1,
        zoomType: 'xy'
    },

    legend: {
        enabled: false
    },

    title: {
        text: 'Political Stability against GDP per capita 1996'
    },

    subtitle: {
        text: 'Sources: <a href="https://ourworldindata.org/grapher/gdp-per-capita-worldbank">GDP: OWID</a> , <a href="https://tcdata360.worldbank.org/indicators/h395cb858?country=BRA&indicator=376&viz=line_chart&years=1996,2020">Political Stability: World Bank</a> , <a href="https://ourworldindata.org/grapher/population-past-future">Population: OWID</a>'
    },

    accessibility: {
        point: {
            valueDescriptionFormat: '{index}. {point.name}, $: {point.x}%, sugar: {point.y}%, obesity: {point.z}.'
        }
    },

    xAxis: {
        gridLineWidth: 1,
        title: {
            text: 'GDP Per Capita'
        },
        labels: {
            format: '{value} $'
        },
        plotLines: [{
            color: '',
            dashStyle: '',
            width: 0,
            value: 0,
            label: {
                rotation: 0,
                y: 0,
                style: {
                    fontStyle: 'italic'
                },
                text: ''
            },
            zIndex: 3
        }],
        accessibility: {
            rangeDescription: 'Range: 60 to 100 grams.'
        }
    },

    yAxis: {
        startOnTick: false,
        endOnTick: false,
        title: {
            text: 'Political Stability %'
        },
        labels: {
            format: '{value} %'
        },
        maxPadding: 0.2,
        plotLines: [{
            color: '',
            dashStyle: '',
            width: 0,
            value: 0,
            label: {
                align: 'right',
                style: {
                    fontStyle: 'italic'
                },
                text: '',
                x: 0
            },
            zIndex: 3
        }],
        accessibility: {
            rangeDescription: 'Range: 0 to 160 grams.'
        }
    },

    tooltip: {
        useHTML: true,
        headerFormat: '<table>',
        pointFormat: '<tr><th colspan="2"><h3>{point.country}</h3></th></tr>' +
            '<tr><th>GDP Per Capita:</th><td>{point.x}$</td></tr>' +
            '<tr><th>Political Stability:</th><td>{point.y}%</td></tr>' +
            '<tr><th>Population:</th><td>{point.z}</td></tr>',
        footerFormat: '</table>',
        followPointer: true
    },

    plotOptions: {
        series: {
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },

    series: [{
       color: '#0e2f44',

        data:[
          {
            "x": 38097.98348,
            "y": 0,
            "z": 83211,
            "name": "AW",
            "country": "Aruba"
          },
          {
            "x": 0,
            "y": 2.12766,
            "z": 18853444,
            "name": "AF",
            "country": "Afghanistan"
          },
          {
            "x": 4551.650381,
            "y": 3.723404,
            "z": 14400722,
            "name": "AO",
            "country": "Angola"
          },
          {
            "x": 4909.228105,
            "y": 35.6383,
            "z": 3098699,
            "name": "AL",
            "country": "Albania"
          },
          {
            "x": 102211.6388,
            "y": 78.19149,
            "z": 2539121,
            "name": "AE",
            "country": "United Arab Emirates"
          },
          {
            "x": 18104.69781,
            "y": 51.06383,
            "z": 35246376,
            "name": "AR",
            "country": "Argentina"
          },
          {
            "x": 3234.069621,
            "y": 34.04255,
            "z": 3168213,
            "name": "AM",
            "country": "Armenia"
          },
          {
            "x": 16303.17628,
            "y": 70.74468,
            "z": 70176,
            "name": "AG",
            "country": "Antigua and Barbuda"
          },
          {
            "x": 33778.06354,
            "y": 96.2766,
            "z": 18189274,
            "name": "AU",
            "country": "Australia"
          },
          {
            "x": 41260.1714,
            "y": 96.80851,
            "z": 8017852,
            "name": "AT",
            "country": "Austria"
          },
          {
            "x": 3033.830388,
            "y": 21.2766,
            "z": 7855558,
            "name": "AZ",
            "country": "Azerbaijan"
          },
          {
            "x": 861.4828791,
            "y": 3.191489,
            "z": 6060110,
            "name": "BI",
            "country": "Burundi"
          },
          {
            "x": 38207.97913,
            "y": 92.02128,
            "z": 10208265,
            "name": "BE",
            "country": "Belgium"
          },
          {
            "x": 2277.761816,
            "y": 84.57447,
            "z": 6094272,
            "name": "BJ",
            "country": "Benin"
          },
          {
            "x": 1162.451422,
            "y": 37.23404,
            "z": 10372734,
            "name": "BF",
            "country": "Burkina Faso"
          },
          {
            "x": 1735.922008,
            "y": 26.59575,
            "z": 117649927,
            "name": "BD",
            "country": "Bangladesh"
          },
          {
            "x": 11588.8398,
            "y": 44.68085,
            "z": 8291969,
            "name": "BG",
            "country": "Bulgaria"
          },
          {
            "x": 47825.87425,
            "y": 36.70213,
            "z": 578661,
            "name": "BH",
            "country": "Bahrain"
          },
          {
            "x": 35656.48521,
            "y": 85.6383,
            "z": 283980,
            "name": "BS",
            "country": "Bahamas"
          },
          {
            "x": 3946.668743,
            "y": 25.53192,
            "z": 3764419,
            "name": "BA",
            "country": "Bosnia and Herzegovina"
          },
          {
            "x": 5987.785689,
            "y": 50,
            "z": 10044854,
            "name": "BY",
            "country": "Belarus"
          },
          {
            "x": 5784.218267,
            "y": 64.3617,
            "z": 213660,
            "name": "BZ",
            "country": "Belize"
          },
          {
            "x": 69643.40752,
            "y": 70.74468,
            "z": 63770,
            "name": "BM",
            "country": "Bermuda"
          },
          {
            "x": 5164.250073,
            "y": 43.08511,
            "z": 7779268,
            "name": "BO",
            "country": "Bolivia"
          },
          {
            "x": 11321.38987,
            "y": 38.82979,
            "z": 164614682,
            "name": "BR",
            "country": "Brazil"
          },
          {
            "x": 13505.79813,
            "y": 84.57447,
            "z": 267047,
            "name": "BB",
            "country": "Barbados"
          },
          {
            "x": 72695.15211,
            "y": 90.42553,
            "z": 304620,
            "name": "BN",
            "country": "Brunei Darussalam"
          },
          {
            "x": 3559.029162,
            "y": 71.2766,
            "z": 541471,
            "name": "BT",
            "country": "Bhutan"
          },
          {
            "x": 10266.24833,
            "y": 79.78723,
            "z": 1504724,
            "name": "BW",
            "country": "Botswana"
          },
          {
            "x": 1027.650038,
            "y": 11.70213,
            "z": 3308235,
            "name": "CF",
            "country": "Central African Republic"
          },
          {
            "x": 0,
            "y": 89.89362,
            "z": 29457820,
            "name": "CA",
            "country": "Canada"
          },
          {
            "x": 54106.57086,
            "y": 99.46809,
            "z": 7038027,
            "name": "CH",
            "country": "Switzerland"
          },
          {
            "x": 13990.9264,
            "y": 68.61702,
            "z": 14587367,
            "name": "CL",
            "country": "Chile"
          },
          {
            "x": 2601.363426,
            "y": 44.14894,
            "z": 1251636178,
            "name": "CN",
            "country": "China"
          },
          {
            "x": 4240.163679,
            "y": 48.93617,
            "z": 14665125,
            "name": "CI",
            "country": "Cote d'Ivoire"
          },
          {
            "x": 2571.744547,
            "y": 19.68085,
            "z": 13970812,
            "name": "CM",
            "country": "Cameroon"
          },
          {
            "x": 1000.689174,
            "y": 0,
            "z": 42757239,
            "name": "CD",
            "country": "DR Congo"
          },
          {
            "x": 4575.149687,
            "y": 11.17021,
            "z": 2785815,
            "name": "CG",
            "country": "Congo Republic"
          },
          {
            "x": 9424.096947,
            "y": 6.914894,
            "z": 37076387,
            "name": "CO",
            "country": "Colombia"
          },
          {
            "x": 2642.093769,
            "y": 62.23404,
            "z": 488625,
            "name": "KM",
            "country": "Comoros"
          },
          {
            "x": 2769.275079,
            "y": 82.44681,
            "z": 395533,
            "name": "CV",
            "country": "Cabo Verde"
          },
          {
            "x": 11255.97406,
            "y": 72.34042,
            "z": 3632361,
            "name": "CR",
            "country": "Costa Rica"
          },
          {
            "x": 0,
            "y": 70.74468,
            "z": 34065,
            "name": "KY",
            "country": "Cayman Islands"
          },
          {
            "x": 28591.26473,
            "y": 60.10638,
            "z": 873426,
            "name": "CY",
            "country": "Cyprus"
          },
          {
            "x": 23756.97839,
            "y": 87.76596,
            "z": 10350302,
            "name": "CZ",
            "country": "Czech Republic"
          },
          {
            "x": 39510.30388,
            "y": 92.02128,
            "z": 81323666,
            "name": "DE",
            "country": "Germany"
          },
          {
            "x": 0,
            "y": 35.10638,
            "z": 643649,
            "name": "DJ",
            "country": "Djibouti"
          },
          {
            "x": 8665.722436,
            "y": 70.74468,
            "z": 70933,
            "name": "DM",
            "country": "Dominica"
          },
          {
            "x": 44013.38559,
            "y": 97.87234,
            "z": 5254857,
            "name": "DK",
            "country": "Denmark"
          },
          {
            "x": 7707.395196,
            "y": 45.21276,
            "z": 7952766,
            "name": "DO",
            "country": "Dominican Republic"
          },
          {
            "x": 8116.959947,
            "y": 5.319149,
            "z": 29266415,
            "name": "DZ",
            "country": "Algeria"
          },
          {
            "x": 8539.337989,
            "y": 22.34043,
            "z": 11703169,
            "name": "EC",
            "country": "Ecuador"
          },
          {
            "x": 6671.089393,
            "y": 27.65957,
            "z": 63601632,
            "name": "EG",
            "country": "Egypt"
          },
          {
            "x": 29691.0968,
            "y": 53.19149,
            "z": 39908962,
            "name": "ES",
            "country": "Spain"
          },
          {
            "x": 13565.45742,
            "y": 72.87234,
            "z": 1417741,
            "name": "EE",
            "country": "Estonia"
          },
          {
            "x": 736.9477942,
            "y": 16.48936,
            "z": 58883531,
            "name": "ET",
            "country": "Ethiopia"
          },
          {
            "x": 32548.01516,
            "y": 97.34042,
            "z": 5136984,
            "name": "FI",
            "country": "Finland"
          },
          {
            "x": 9344.222531,
            "y": 73.40426,
            "z": 784389,
            "name": "FJ",
            "country": "Fiji"
          },
          {
            "x": 35548.62852,
            "y": 76.59574,
            "z": 58012055,
            "name": "FR",
            "country": "France"
          },
          {
            "x": 3316.51308,
            "y": 0,
            "z": 108311,
            "name": "FM",
            "country": "Micronesia, Fed. Sts."
          },
          {
            "x": 18703.16665,
            "y": 51.59575,
            "z": 1112944,
            "name": "GA",
            "country": "Gabon"
          },
          {
            "x": 33298.12816,
            "y": 78.7234,
            "z": 58113554,
            "name": "GB",
            "country": "United Kingdom"
          },
          {
            "x": 3740.485453,
            "y": 7.446808,
            "z": 4846627,
            "name": "GE",
            "country": "Georgia"
          },
          {
            "x": 2556.355029,
            "y": 38.29787,
            "z": 17462504,
            "name": "GH",
            "country": "Ghana"
          },
          {
            "x": 1622.749207,
            "y": 13.29787,
            "z": 7463782,
            "name": "GN",
            "country": "Guinea"
          },
          {
            "x": 2108.828492,
            "y": 64.89362,
            "z": 1164091,
            "name": "GM",
            "country": "Gambia"
          },
          {
            "x": 2284.369157,
            "y": 8.510638,
            "z": 1110835,
            "name": "GW",
            "country": "Guinea-Bissau"
          },
          {
            "x": 2857.502271,
            "y": 43.61702,
            "z": 515844,
            "name": "GQ",
            "country": "Equatorial Guinea"
          },
          {
            "x": 25567.25646,
            "y": 63.82979,
            "z": 10832139,
            "name": "GR",
            "country": "Greece"
          },
          {
            "x": 8985.947967,
            "y": 77.12766,
            "z": 101003,
            "name": "GD",
            "country": "Grenada"
          },
          {
            "x": 6064.020818,
            "y": 17.55319,
            "z": 10646676,
            "name": "GT",
            "country": "Guatemala"
          },
          {
            "x": 7198.835867,
            "y": 37.76596,
            "z": 760801,
            "name": "GY",
            "country": "Guyana"
          },
          {
            "x": 34453.83658,
            "y": 67.02128,
            "z": 6185584,
            "name": "HK",
            "country": "Hong Kong"
          },
          {
            "x": 3984.568827,
            "y": 30.31915,
            "z": 5874814,
            "name": "HN",
            "country": "Honduras"
          },
          {
            "x": 16108.026,
            "y": 47.34043,
            "z": 4574888,
            "name": "HR",
            "country": "Croatia"
          },
          {
            "x": 2649.525671,
            "y": 22.87234,
            "z": 7887312,
            "name": "HT",
            "country": "Haiti"
          },
          {
            "x": 16652.58523,
            "y": 79.25532,
            "z": 10332451,
            "name": "HU",
            "country": "Hungary"
          },
          {
            "x": 6258.436533,
            "y": 13.82979,
            "z": 199901231,
            "name": "ID",
            "country": "Indonesia"
          },
          {
            "x": 2220.893203,
            "y": 19.14894,
            "z": 982365248,
            "name": "IN",
            "country": "India"
          },
          {
            "x": 34856.46939,
            "y": 95.21277,
            "z": 3619633,
            "name": "IE",
            "country": "Ireland"
          },
          {
            "x": 9670.2045,
            "y": 36.17021,
            "z": 62294919,
            "name": "IR",
            "country": "Iran"
          },
          {
            "x": 4710.353103,
            "y": 4.787234,
            "z": 20783073,
            "name": "IQ",
            "country": "Iraq"
          },
          {
            "x": 35014.23134,
            "y": 94.14893,
            "z": 270144,
            "name": "IS",
            "country": "Iceland"
          },
          {
            "x": 28986.204,
            "y": 12.76596,
            "z": 5424241,
            "name": "IL",
            "country": "Israel"
          },
          {
            "x": 39429.49556,
            "y": 86.70213,
            "z": 57065231,
            "name": "IT",
            "country": "Italy"
          },
          {
            "x": 9850.988347,
            "y": 50.53191,
            "z": 2558631,
            "name": "JM",
            "country": "Jamaica"
          },
          {
            "x": 8248.917899,
            "y": 46.80851,
            "z": 4732848,
            "name": "JO",
            "country": "Jordan"
          },
          {
            "x": 35058.80366,
            "y": 88.29787,
            "z": 126644099,
            "name": "JP",
            "country": "Japan"
          },
          {
            "x": 8726.538477,
            "y": 33.51064,
            "z": 15631926,
            "name": "KZ",
            "country": "Kazakhstan"
          },
          {
            "x": 3001.868379,
            "y": 23.93617,
            "z": 28589456,
            "name": "KE",
            "country": "Kenya"
          },
          {
            "x": 2656.01772,
            "y": 41.48936,
            "z": 4629403,
            "name": "KG",
            "country": "Kyrgyz Republic"
          },
          {
            "x": 1214.926365,
            "y": 14.89362,
            "z": 10982919,
            "name": "KH",
            "country": "Cambodia"
          },
          {
            "x": 2061.102071,
            "y": 0,
            "z": 78904,
            "name": "KI",
            "country": "Kiribati"
          },
          {
            "x": 18446.67623,
            "y": 0,
            "z": 42472,
            "name": "KN",
            "country": "St. Kitts and Nevis"
          },
          {
            "x": 19364.94137,
            "y": 65.95744,
            "z": 45751023,
            "name": "KR",
            "country": "South Korea"
          },
          {
            "x": 63284.69581,
            "y": 52.65957,
            "z": 1626858,
            "name": "KW",
            "country": "Kuwait"
          },
          {
            "x": 2438.904044,
            "y": 59.57447,
            "z": 4951189,
            "name": "LA",
            "country": "Laos"
          },
          {
            "x": 14473.38323,
            "y": 23.40425,
            "z": 3610663,
            "name": "LB",
            "country": "Lebanon"
          },
          {
            "x": 0,
            "y": 1.595745,
            "z": 2160480,
            "name": "LR",
            "country": "Liberia"
          },
          {
            "x": 0,
            "y": 18.61702,
            "z": 5036173,
            "name": "LY",
            "country": "Libya"
          },
          {
            "x": 12591.69123,
            "y": 82.44681,
            "z": 148837,
            "name": "LC",
            "country": "St. Lucia"
          },
          {
            "x": 4938.710274,
            "y": 5.851064,
            "z": 18367290,
            "name": "LK",
            "country": "Sri Lanka"
          },
          {
            "x": 1611.650905,
            "y": 54.25532,
            "z": 1934294,
            "name": "LS",
            "country": "Lesotho"
          },
          {
            "x": 11274.64011,
            "y": 62.76596,
            "z": 3603756,
            "name": "LT",
            "country": "Lithuania"
          },
          {
            "x": 76741.05908,
            "y": 95.74468,
            "z": 413999,
            "name": "LU",
            "country": "Luxembourg"
          },
          {
            "x": 9861.003287,
            "y": 65.42553,
            "z": 2478832,
            "name": "LV",
            "country": "Latvia"
          },
          {
            "x": 56472.99029,
            "y": 56.91489,
            "z": 393376,
            "name": "MO",
            "country": "Macau"
          },
          {
            "x": 4231.492166,
            "y": 39.89362,
            "z": 27383472,
            "name": "MA",
            "country": "Morocco"
          },
          {
            "x": 5372.138502,
            "y": 47.87234,
            "z": 4316225,
            "name": "MD",
            "country": "Moldova"
          },
          {
            "x": 1553.5749,
            "y": 53.7234,
            "z": 13902697,
            "name": "MG",
            "country": "Madagascar"
          },
          {
            "x": 11208.83899,
            "y": 76.06383,
            "z": 259178,
            "name": "MV",
            "country": "Maldives"
          },
          {
            "x": 15559.97637,
            "y": 20.74468,
            "z": 93147045,
            "name": "MX",
            "country": "Mexico"
          },
          {
            "x": 3608.883906,
            "y": 0,
            "z": 50523,
            "name": "MH",
            "country": "Marshall Islands"
          },
          {
            "x": 9103.878091,
            "y": 29.25532,
            "z": 1989441,
            "name": "MK",
            "country": "Macedonia"
          },
          {
            "x": 1520.456928,
            "y": 58.51064,
            "z": 9837575,
            "name": "ML",
            "country": "Mali"
          },
          {
            "x": 20348.54774,
            "y": 94.14893,
            "z": 380259,
            "name": "MT",
            "country": "Malta"
          },
          {
            "x": 814.4463403,
            "y": 10.10638,
            "z": 44452203,
            "name": "MM",
            "country": "Myanmar"
          },
          {
            "x": 0,
            "y": 0,
            "z": 619705,
            "name": "ME",
            "country": "Montenegro"
          },
          {
            "x": 4187.388444,
            "y": 71.80851,
            "z": 2316571,
            "name": "MN",
            "country": "Mongolia"
          },
          {
            "x": 506.1518205,
            "y": 46.2766,
            "z": 15960445,
            "name": "MZ",
            "country": "Mozambique"
          },
          {
            "x": 4920.880763,
            "y": 59.04255,
            "z": 2372900,
            "name": "MR",
            "country": "Mauritania"
          },
          {
            "x": 9998.617114,
            "y": 86.17021,
            "z": 1141952,
            "name": "MU",
            "country": "Mauritius"
          },
          {
            "x": 1091.511334,
            "y": 31.91489,
            "z": 10022783,
            "name": "MW",
            "country": "Malawi"
          },
          {
            "x": 15290.91444,
            "y": 66.48936,
            "z": 21017619,
            "name": "MY",
            "country": "Malaysia"
          },
          {
            "x": 6374.949609,
            "y": 74.46809,
            "z": 1663378,
            "name": "NA",
            "country": "Namibia"
          },
          {
            "x": 977.9036945,
            "y": 48.40425,
            "z": 9826600,
            "name": "NE",
            "country": "Niger"
          },
          {
            "x": 2949.200357,
            "y": 15.95745,
            "z": 110668784,
            "name": "NG",
            "country": "Nigeria"
          },
          {
            "x": 3531.727044,
            "y": 28.19149,
            "z": 4741571,
            "name": "NI",
            "country": "Nicaragua"
          },
          {
            "x": 40691.89032,
            "y": 100,
            "z": 15563252,
            "name": "NL",
            "country": "Netherlands"
          },
          {
            "x": 51476.21521,
            "y": 99.46809,
            "z": 4393217,
            "name": "NO",
            "country": "Norway"
          },
          {
            "x": 1876.464286,
            "y": 45.74468,
            "z": 22090352,
            "name": "NP",
            "country": "Nepal"
          },
          {
            "x": 0,
            "y": 0,
            "z": 10677,
            "name": "NR",
            "country": "Nauru"
          },
          {
            "x": 30409.09066,
            "y": 94.68085,
            "z": 3717352,
            "name": "NZ",
            "country": "New Zealand"
          },
          {
            "x": 29491.63777,
            "y": 75,
            "z": 2236652,
            "name": "OM",
            "country": "Oman"
          },
          {
            "x": 3240.088797,
            "y": 14.3617,
            "z": 127349293,
            "name": "PK",
            "country": "Pakistan"
          },
          {
            "x": 12889.27081,
            "y": 52.12766,
            "z": 2796291,
            "name": "PA",
            "country": "Panama"
          },
          {
            "x": 6210.222642,
            "y": 15.42553,
            "z": 24753825,
            "name": "PE",
            "country": "Peru"
          },
          {
            "x": 4322.085078,
            "y": 29.78723,
            "z": 71401743,
            "name": "PH",
            "country": "Philippines"
          },
          {
            "x": 0,
            "y": 0,
            "z": 17599,
            "name": "PW",
            "country": "Palau"
          },
          {
            "x": 3440.330057,
            "y": 21.80851,
            "z": 5314258,
            "name": "PG",
            "country": "Papua New Guinea"
          },
          {
            "x": 13211.56797,
            "y": 73.93617,
            "z": 38509672,
            "name": "PL",
            "country": "Poland"
          },
          {
            "x": 25584.55937,
            "y": 56.91489,
            "z": 3596099,
            "name": "PR",
            "country": "Puerto Rico"
          },
          {
            "x": 26318.97513,
            "y": 90.95744,
            "z": 10134016,
            "name": "PT",
            "country": "Portugal"
          },
          {
            "x": 9243.474955,
            "y": 31.38298,
            "z": 4887638,
            "name": "PY",
            "country": "Paraguay"
          },
          {
            "x": 3916.925775,
            "y": 7.978724,
            "z": 2742534,
            "name": "PS",
            "country": "Palestine"
          },
          {
            "x": 0,
            "y": 57.97872,
            "z": 522530,
            "name": "QA",
            "country": "Qatar"
          },
          {
            "x": 12627.2027,
            "y": 67.55319,
            "z": 22805706,
            "name": "RO",
            "country": "Romania"
          },
          {
            "x": 12827.11625,
            "y": 12.23404,
            "z": 148020852,
            "name": "RU",
            "country": "Russia"
          },
          {
            "x": 816.7606261,
            "y": 4.255319,
            "z": 6013112,
            "name": "RW",
            "country": "Rwanda"
          },
          {
            "x": 43073.13082,
            "y": 40.95745,
            "z": 19033843,
            "name": "SA",
            "country": "Saudi Arabia"
          },
          {
            "x": 1861.146769,
            "y": 1.06383,
            "z": 24782384,
            "name": "SD",
            "country": "Sudan"
          },
          {
            "x": 2367.648145,
            "y": 25,
            "z": 8912872,
            "name": "SN",
            "country": "Senegal"
          },
          {
            "x": 50410.28181,
            "y": 87.23404,
            "z": 3638177,
            "name": "SG",
            "country": "Singapore"
          },
          {
            "x": 2939.337979,
            "y": 82.44681,
            "z": 369517,
            "name": "SB",
            "country": "Solomon Islands"
          },
          {
            "x": 1128.597284,
            "y": 6.382979,
            "z": 4312660,
            "name": "SL",
            "country": "Sierra Leone"
          },
          {
            "x": 6195.504554,
            "y": 39.3617,
            "z": 5689943,
            "name": "SV",
            "country": "El Salvador"
          },
          {
            "x": 0,
            "y": 0,
            "z": 26253,
            "name": "SM",
            "country": "San Marino"
          },
          {
            "x": 0,
            "y": 0.5319149,
            "z": 7682683,
            "name": "SO",
            "country": "Somalia"
          },
          {
            "x": 8245.97008,
            "y": 17.02128,
            "z": 9856064,
            "name": "RS",
            "country": "Serbia"
          },
          {
            "x": 0,
            "y": 84.57447,
            "z": 133799,
            "name": "ST",
            "country": "Sao Tome and Principe"
          },
          {
            "x": 12614.01486,
            "y": 60.6383,
            "z": 448207,
            "name": "SR",
            "country": "Suriname"
          },
          {
            "x": 14096.77228,
            "y": 75.53191,
            "z": 5384792,
            "name": "SK",
            "country": "Slovakia"
          },
          {
            "x": 22185.69296,
            "y": 92.55319,
            "z": 1988580,
            "name": "SI",
            "country": "Slovenia"
          },
          {
            "x": 34719.11075,
            "y": 99.46809,
            "z": 8859180,
            "name": "SE",
            "country": "Sweden"
          },
          {
            "x": 5353.189064,
            "y": 40.42553329,
            "z": 945506,
            "name": "SZ",
            "country": "Eswatini"
          },
          {
            "x": 16013.26099,
            "y": 84.57447,
            "z": 77597,
            "name": "SC",
            "country": "Seychelles"
          },
          {
            "x": 929.5803706,
            "y": 18.08511,
            "z": 7250974,
            "name": "TD",
            "country": "Chad"
          },
          {
            "x": 1694.648022,
            "y": 32.97872,
            "z": 4348808,
            "name": "TG",
            "country": "Togo"
          },
          {
            "x": 10467.45461,
            "y": 61.70213,
            "z": 60130190,
            "name": "TH",
            "country": "Thailand"
          },
          {
            "x": 1170.149174,
            "y": 3.191489,
            "z": 5851354,
            "name": "TJ",
            "country": "Tajikistan"
          },
          {
            "x": 4175.819837,
            "y": 61.17021,
            "z": 4287337,
            "name": "TM",
            "country": "Turkmenistan"
          },
          {
            "x": 0,
            "y": 0,
            "z": 855358,
            "name": "TL",
            "country": "Timor-Leste"
          },
          {
            "x": 4721.574789,
            "y": 0,
            "z": 96267,
            "name": "TO",
            "country": "Tonga"
          },
          {
            "x": 12713.82418,
            "y": 57.44681,
            "z": 1257547,
            "name": "TT",
            "country": "Trinidad and Tobago"
          },
          {
            "x": 6257.986611,
            "y": 55.31915,
            "z": 9267335,
            "name": "TN",
            "country": "Tunisia"
          },
          {
            "x": 14413.16073,
            "y": 10.6383,
            "z": 59423278,
            "name": "TR",
            "country": "Turkey"
          },
          {
            "x": 2727.280272,
            "y": 0,
            "z": 9317,
            "name": "TV",
            "country": "Tuvalu"
          },
          {
            "x": 1317.559858,
            "y": 24.46808,
            "z": 30444523,
            "name": "TZ",
            "country": "Tanzania"
          },
          {
            "x": 1146.373034,
            "y": 9.042553,
            "z": 21032817,
            "name": "UG",
            "country": "Uganda"
          },
          {
            "x": 6915.978305,
            "y": 42.55319,
            "z": 50580467,
            "name": "UA",
            "country": "Ukraine"
          },
          {
            "x": 13569.80902,
            "y": 68.08511,
            "z": 3247383,
            "name": "UY",
            "country": "Uruguay"
          },
          {
            "x": 44105.82746,
            "y": 77.65958,
            "z": 268335007,
            "name": "US",
            "country": "United States"
          },
          {
            "x": 2488.790383,
            "y": 27.12766,
            "z": 23225303,
            "name": "UZ",
            "country": "Uzbekistan"
          },
          {
            "x": 7673.799557,
            "y": 82.44681,
            "z": 107983,
            "name": "VC",
            "country": "St. Vincent and the Grenadines"
          },
          {
            "x": 2425.526393,
            "y": 63.29787,
            "z": 76068739,
            "name": "VN",
            "country": "Vietnam"
          },
          {
            "x": 2929.461465,
            "y": 82.44681,
            "z": 171721,
            "name": "VU",
            "country": "Vanuatu"
          },
          {
            "x": 4361.991269,
            "y": 93.08511,
            "z": 171165,
            "name": "WS",
            "country": "Samoa"
          },
          {
            "x": 9761.738955,
            "y": 32.44681,
            "z": 42241007,
            "name": "ZA",
            "country": "South Africa"
          },
          {
            "x": 1974.61507,
            "y": 42.02128,
            "z": 9339740,
            "name": "ZM",
            "country": "Zambia"
          },
          {
            "x": 3806.967546,
            "y": 30.85106,
            "z": 11541215,
            "name": "ZW",
            "country": "Zimbabwe"
          }
         ]
    }]

});
