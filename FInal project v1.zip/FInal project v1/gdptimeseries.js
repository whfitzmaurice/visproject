Highcharts.chart('container', {
    chart: {
        zoomType: 'x'
    },
    title: {
        text: 'Average Per Capita GDP 1990 - 2020'
    },
    subtitle: {
        text: 'Source: <a href="https://ourworldindata.org/grapher/gdp-per-capita-worldbank">GDP: OWID</a>'
    },
    xAxis: {
        type: 'year'
    },
    yAxis: {
        title: {
            text: 'Per Capita GDP'
        }
    },
    legend: {
        enabled: false
    },
    plotOptions: {
        line: {
            fillColor: '#daa520',
            marker: {
                radius: 5
            },
            lineWidth: 3,
            states: {
                hover: {
                    lineWidth: 3
                }
            },
            threshold: null
        }
    },

    series: [{
        type: '',
        color: '#daa520',
        name: 'Per Capita GDP',
        data: [
            [1990,10930.84651  ],
            [1991,11011.82544  ],
            [1992,11114.19422  ],
            [1993,11168.68704  ],
            [1994,11363.76977  ],
            [1995,12718.51738  ],
            [1996,12996.64076  ],
            [1997,13952.94422  ],
            [1998,14176.61461  ],
            [1999,14535.19274  ],
            [2000,15789.60499  ],
            [2001,16007.74221  ],
            [2002,16216.17789  ],
            [2003,16594.36681  ],
            [2004,17321.65757  ],
            [2005,17767.57412  ],
            [2006,18864.84124  ],
            [2007,19522.6256  ],
            [2008,19632.10204  ],
            [2009,19020.38091  ],
            [2010,19422.15238  ],
            [2011,19928.64093  ],
            [2012,20099.55962  ],
            [2013,20362.1863  ],
            [2014,20581.71949  ],
            [2015,20737.13878  ],
            [2016,20991.68492  ],
            [2017,21377.52616  ],
            [2018,21561.97168  ],
            [2019,21598.69457  ],
            [2020,17609.96873  ]
          ]
    }]
});
