Highcharts.chart('container', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Average Happiness 2020 - 2021'
    },
    subtitle: {
        text: 'Source: <a href="https://worldpopulationreview.com/country-rankings/happiest-countries-in-the-world">Happiness: World Happiness Report</a>'
    },
    xAxis: {
        type: 'category',
        labels: {
            rotation: -45,
            style: {
                fontSize: '13px',
                fontFamily: 'Verdana, sans-serif'
            }
        }
    },
    yAxis: {
        min: 0,
        max: 100,
        title: {
            text: 'Happiness %'
        }
    },
    legend: {
        enabled: false
    },
    tooltip: {
        pointFormat: 'Happiness: <b>{point.y:.1f} %</b>'
    },
    series: [{
        color: '#ff1493',
        name: 'Population',
        data: [
            [2020,55.08445205  ],
            [2021,55.34027397  ]
          ],
        dataLabels: {
            enabled: true,
            rotation: -90,
            color: '#FFFFFF',
            align: 'right',
            format: '{point.y:.1f}', // one decimal
            y: 10, // 10 pixels down from the top
            style: {
                fontSize: '13px',
                fontFamily: 'Verdana, sans-serif'
            }
        }
    }]
});