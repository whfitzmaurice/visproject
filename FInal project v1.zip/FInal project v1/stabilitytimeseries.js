Highcharts.chart('container', {
    chart: {
        zoomType: 'x'
    },
    title: {
        text: 'Average Political Stability 1996 - 2020'
    },
    subtitle: {
        text: 'Source: <a href="https://tcdata360.worldbank.org/indicators/h395cb858?country=BRA&indicator=376&viz=line_chart&years=1996,2020">Political Stability: World Bank</a>'
    },
    xAxis: {
        type: 'year'
    },
    yAxis: {
        min: 40,
        max: 55,
        tickInterval: 1,
        title: {
            text: 'Political Stability %'
        }
    },
    legend: {
        enabled: false
    },
    plotOptions: {
        line: {
            fillColor: '#0e2f44',
            marker: {
                radius: 5
            },
            lineWidth: 3,
            states: {
                hover: {
                    lineWidth: 3
                }
            },
            threshold: null
        }
    },

    series: [{
        type: '',
        color: '#0e2f44',
        name: 'Political Stability %',
        data: [
            [1996,45.43999172  ],
            [1998,45.41933465  ],
            [2000,45.60024659  ],
            [2002,45.53860393  ],
            [2003,48.02654043  ],
            [2004,48.5436891  ],
            [2005,48.49891583  ],
            [2006,48.68205073  ],
            [2007,48.67032514  ],
            [2008,49.06179981  ],
            [2009,49.00842038  ],
            [2010,48.86117895  ],
            [2011,49.18326976  ],
            [2012,49.22468151  ],
            [2013,49.30750473  ],
            [2014,49.34350436  ],
            [2015,49.29727227  ],
            [2016,49.30883033  ],
            [2017,49.12621363  ],
            [2018,48.67420769  ],
            [2019,48.60093424  ],
            [2020,48.55284861  ]
          ]
    }]
});
