

Highcharts.chart('container', {

    chart: {
        type: 'bubble',
        plotBorderWidth: 1,
        zoomType: 'xy'
    },

    legend: {
        enabled: false
    },

    title: {
        text: 'Resource Income against GDP per capita 2010'
    },

    subtitle: {
        text: 'Sources: <a href="https://ourworldindata.org/grapher/gdp-per-capita-worldbank">GDP: OWID</a> , <a href="https://data.worldbank.org/indicator/NY.GDP.TOTL.RT.ZS">Resource Endowments: World Bank</a> , <a href="https://ourworldindata.org/grapher/population-past-future">Population: OWID</a>'
    },

    accessibility: {
        point: {
            valueDescriptionFormat: '{index}. {point.name}, $: {point.x}%, sugar: {point.y}%, obesity: {point.z}.'
        }
    },

    xAxis: {
        gridLineWidth: 1,
        title: {
            text: 'GDP Per Capita'
        },
        labels: {
            format: '{value} $'
        },
        plotLines: [{
            color: '',
            dashStyle: '',
            width: 0,
            value: 0,
            label: {
                rotation: 0,
                y: 0,
                style: {
                    fontStyle: 'italic'
                },
                text: ''
            },
            zIndex: 3
        }],
        accessibility: {
            rangeDescription: 'Range: 60 to 100 grams.'
        }
    },

    yAxis: {
        startOnTick: false,
        endOnTick: false,
        title: {
            text: 'Resources Income %'
        },
        labels: {
            format: '{value} %'
        },
        maxPadding: 0.2,
        plotLines: [{
            color: '',
            dashStyle: '',
            width: 0,
            value: 0,
            label: {
                align: 'right',
                style: {
                    fontStyle: 'italic'
                },
                text: '',
                x: 0
            },
            zIndex: 3
        }],
        accessibility: {
            rangeDescription: 'Range: 0 to 160 grams.'
        }
    },

    tooltip: {
        useHTML: true,
        headerFormat: '<table>',
        pointFormat: '<tr><th colspan="2"><h3>{point.country}</h3></th></tr>' +
            '<tr><th>GDP Per Capita:</th><td>{point.x}$</td></tr>' +
            '<tr><th>Resources Income:</th><td>{point.y}%</td></tr>' +
            '<tr><th>Population:</th><td>{point.z}</td></tr>',
        footerFormat: '</table>',
        followPointer: true
    },

    plotOptions: {
        series: {
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },

    series: [{
        color: '#794044',

        data:[
          {
            "x": 34343.15132,
            "y": 0.002361284,
            "z": 101665,
            "name": "AW",
            "country": "Aruba"
          },
          {
            "x": 1957.02907,
            "y": 0.61264487,
            "z": 29185511,
            "name": "AF",
            "country": "Afghanistan"
          },
          {
            "x": 7692.434286,
            "y": 40.18684246,
            "z": 23356247,
            "name": "AO",
            "country": "Angola"
          },
          {
            "x": 10749.48745,
            "y": 1.574519863,
            "z": 2948029,
            "name": "AL",
            "country": "Albania"
          },
          {
            "x": 54921.77558,
            "y": 22.6020273,
            "z": 8549998,
            "name": "AE",
            "country": "United Arab Emirates"
          },
          {
            "x": 23521.27018,
            "y": 3.326284235,
            "z": 40895751,
            "name": "AR",
            "country": "Argentina"
          },
          {
            "x": 9286.197327,
            "y": 2.65466288,
            "z": 2877314,
            "name": "AM",
            "country": "Armenia"
          },
          {
            "x": 18205.73853,
            "y": 0,
            "z": 88030,
            "name": "AG",
            "country": "Antigua and Barbuda"
          },
          {
            "x": 44991.78371,
            "y": 8.09514404,
            "z": 22154687,
            "name": "AU",
            "country": "Australia"
          },
          {
            "x": 51769.14556,
            "y": 0.225854257,
            "z": 8409945,
            "name": "AT",
            "country": "Austria"
          },
          {
            "x": 14312.75612,
            "y": 32.13909403,
            "z": 9032465,
            "name": "AZ",
            "country": "Azerbaijan"
          },
          {
            "x": 846.1691368,
            "y": 23.8533749,
            "z": 8675606,
            "name": "BI",
            "country": "Burundi"
          },
          {
            "x": 47971.63031,
            "y": 0.019304595,
            "z": 10938735,
            "name": "BE",
            "country": "Belgium"
          },
          {
            "x": 2704.705484,
            "y": 3.42233007,
            "z": 9199254,
            "name": "BJ",
            "country": "Benin"
          },
          {
            "x": 1716.358323,
            "y": 11.08609183,
            "z": 15605211,
            "name": "BF",
            "country": "Burkina Faso"
          },
          {
            "x": 2883.466794,
            "y": 1.149118824,
            "z": 147575433,
            "name": "BD",
            "country": "Bangladesh"
          },
          {
            "x": 17440.67188,
            "y": 1.692842334,
            "z": 7425011,
            "name": "BG",
            "country": "Bulgaria"
          },
          {
            "x": 44599.80497,
            "y": 19.87626768,
            "z": 1240864,
            "name": "BH",
            "country": "Bahrain"
          },
          {
            "x": 36504.40705,
            "y": 0.015294778,
            "z": 354936,
            "name": "BS",
            "country": "Bahamas"
          },
          {
            "x": 10938.28505,
            "y": 2.745565699,
            "z": 3705478,
            "name": "BA",
            "country": "Bosnia and Herzegovina"
          },
          {
            "x": 17288.40435,
            "y": 1.331911272,
            "z": 9420576,
            "name": "BY",
            "country": "Belarus"
          },
          {
            "x": 7294.684143,
            "y": 5.354010461,
            "z": 322465,
            "name": "BZ",
            "country": "Belize"
          },
          {
            "x": 88399.91595,
            "y": 0,
            "z": 65388,
            "name": "BM",
            "country": "Bermuda"
          },
          {
            "x": 6612.803357,
            "y": 9.287894404,
            "z": 10048597,
            "name": "BO",
            "country": "Bolivia"
          },
          {
            "x": 14873.20832,
            "y": 3.65817419,
            "z": 195713637,
            "name": "BR",
            "country": "Brazil"
          },
          {
            "x": 15596.61681,
            "y": 0.38320514,
            "z": 282131,
            "name": "BB",
            "country": "Barbados"
          },
          {
            "x": 67753.42177,
            "y": 23.62676836,
            "z": 388634,
            "name": "BN",
            "country": "Brunei Darussalam"
          },
          {
            "x": 8190.576223,
            "y": 5.305074675,
            "z": 685502,
            "name": "BT",
            "country": "Bhutan"
          },
          {
            "x": 14126.38227,
            "y": 2.080608591,
            "z": 1987106,
            "name": "BW",
            "country": "Botswana"
          },
          {
            "x": 1201.352197,
            "y": 7.898561965,
            "z": 4386765,
            "name": "CF",
            "country": "Central African Republic"
          },
          {
            "x": 44861.52396,
            "y": 2.240721222,
            "z": 34147566,
            "name": "CA",
            "country": "Canada"
          },
          {
            "x": 65819.73725,
            "y": 0.014934629,
            "z": 7808674,
            "name": "CH",
            "country": "Switzerland"
          },
          {
            "x": 21262.46699,
            "y": 11.92545391,
            "z": 17062531,
            "name": "CL",
            "country": "Chile"
          },
          {
            "x": 8884.588031,
            "y": 6.299459003,
            "z": 1368810604,
            "name": "CN",
            "country": "China"
          },
          {
            "x": 3660.903847,
            "y": 4.603858992,
            "z": 20532944,
            "name": "CI",
            "country": "Cote d'Ivoire"
          },
          {
            "x": 3086.221474,
            "y": 7.140780998,
            "z": 20341236,
            "name": "CM",
            "country": "Cameroon"
          },
          {
            "x": 865.6840402,
            "y": 25.9465394,
            "z": 64563853,
            "name": "CD",
            "country": "DR Congo"
          },
          {
            "x": 5172.760902,
            "y": 47.09770176,
            "z": 4273738,
            "name": "CG",
            "country": "Congo Republic"
          },
          {
            "x": 11783.29991,
            "y": 6.596511319,
            "z": 45222699,
            "name": "CO",
            "country": "Colombia"
          },
          {
            "x": 2878.26971,
            "y": 1.593442325,
            "z": 689696,
            "name": "KM",
            "country": "Comoros"
          },
          {
            "x": 6200.343537,
            "y": 33.27600034,
            "z": 492644,
            "name": "CV",
            "country": "Cabo Verde"
          },
          {
            "x": 16830.43618,
            "y": 1.627167159,
            "z": 4577371,
            "name": "CR",
            "country": "Costa Rica"
          },
          {
            "x": 28543.36071,
            "y": 0,
            "z": 149188,
            "name": "CW",
            "country": "Curacao"
          },
          {
            "x": 66882.50759,
            "y": 0,
            "z": 56672,
            "name": "KY",
            "country": "Cayman Islands"
          },
          {
            "x": 38379.0904,
            "y": 0.039179415,
            "z": 1112617,
            "name": "CY",
            "country": "Cyprus"
          },
          {
            "x": 33483.13759,
            "y": 0.979545198,
            "z": 10536514,
            "name": "CZ",
            "country": "Czech Republic"
          },
          {
            "x": 46929.99341,
            "y": 0.197318068,
            "z": 80827001,
            "name": "DE",
            "country": "Germany"
          },
          {
            "x": 0,
            "y": 0.838156181,
            "z": 840194,
            "name": "DJ",
            "country": "Djibouti"
          },
          {
            "x": 12003.76608,
            "y": 0.04915488,
            "z": 70877,
            "name": "DM",
            "country": "Dominica"
          },
          {
            "x": 50825.41229,
            "y": 1.430260343,
            "z": 5554849,
            "name": "DK",
            "country": "Denmark"
          },
          {
            "x": 12782.45717,
            "y": 0.172400177,
            "z": 9695117,
            "name": "DO",
            "country": "Dominican Republic"
          },
          {
            "x": 10970.70637,
            "y": 26.22109085,
            "z": 35977451,
            "name": "DZ",
            "country": "Algeria"
          },
          {
            "x": 10340.9703,
            "y": 11.87464132,
            "z": 15011114,
            "name": "EC",
            "country": "Ecuador"
          },
          {
            "x": 10340.07323,
            "y": 8.989051363,
            "z": 82761244,
            "name": "EG",
            "country": "Egypt"
          },
          {
            "x": 37319.47622,
            "y": 0.059121531,
            "z": 46931011,
            "name": "ES",
            "country": "Spain"
          },
          {
            "x": 26133.38181,
            "y": 1.962478821,
            "z": 1332103,
            "name": "EE",
            "country": "Estonia"
          },
          {
            "x": 1259.022581,
            "y": 15.81413982,
            "z": 87639962,
            "name": "ET",
            "country": "Ethiopia"
          },
          {
            "x": 45874.6613,
            "y": 0.469623074,
            "z": 5365784,
            "name": "FI",
            "country": "Finland"
          },
          {
            "x": 10547.9304,
            "y": 2.208832941,
            "z": 859816,
            "name": "FJ",
            "country": "Fiji"
          },
          {
            "x": 42147.67168,
            "y": 0.05641749,
            "z": 62879535,
            "name": "FR",
            "country": "France"
          },
          {
            "x": 3659.638766,
            "y": 0.027273282,
            "z": 102916,
            "name": "FM",
            "country": "Micronesia, Fed. Sts."
          },
          {
            "x": 14415.44591,
            "y": 31.8388122,
            "z": 1624146,
            "name": "GA",
            "country": "Gabon"
          },
          {
            "x": 42089.01364,
            "y": 0.978171874,
            "z": 63459801,
            "name": "GB",
            "country": "United Kingdom"
          },
          {
            "x": 9736.732094,
            "y": 1.35568973,
            "z": 4099095,
            "name": "GE",
            "country": "Georgia"
          },
          {
            "x": 3729.475903,
            "y": 10.13334343,
            "z": 24779614,
            "name": "GH",
            "country": "Ghana"
          },
          {
            "x": 1870.800051,
            "y": 15.29208035,
            "z": 10192168,
            "name": "GN",
            "country": "Guinea"
          },
          {
            "x": 2346.720479,
            "y": 3.030324075,
            "z": 1793199,
            "name": "GM",
            "country": "Gambia"
          },
          {
            "x": 1747.237485,
            "y": 14.93073249,
            "z": 1522603,
            "name": "GW",
            "country": "Guinea-Bissau"
          },
          {
            "x": 34732.21915,
            "y": 37.98485261,
            "z": 943640,
            "name": "GQ",
            "country": "Equatorial Guinea"
          },
          {
            "x": 33753.61775,
            "y": 0.274900745,
            "z": 10887640,
            "name": "GR",
            "country": "Greece"
          },
          {
            "x": 13412.79337,
            "y": 0,
            "z": 106227,
            "name": "GD",
            "country": "Grenada"
          },
          {
            "x": 7335.988974,
            "y": 2.648843596,
            "z": 14630420,
            "name": "GT",
            "country": "Guatemala"
          },
          {
            "x": 9789.0167,
            "y": 14.59220398,
            "z": 749430,
            "name": "GY",
            "country": "Guyana"
          },
          {
            "x": 51360.96698,
            "y": 0.001438995,
            "z": 6966324,
            "name": "HK",
            "country": "Hong Kong"
          },
          {
            "x": 4866.973931,
            "y": 2.379086993,
            "z": 8317467,
            "name": "HN",
            "country": "Honduras"
          },
          {
            "x": 24280.60269,
            "y": 1.041339314,
            "z": 4328163,
            "name": "HR",
            "country": "Croatia"
          },
          {
            "x": 2735.283617,
            "y": 0.665741356,
            "z": 9949318,
            "name": "HT",
            "country": "Haiti"
          },
          {
            "x": 24427.62873,
            "y": 0.551878935,
            "z": 9927380,
            "name": "HU",
            "country": "Hungary"
          },
          {
            "x": 8286.73287,
            "y": 7.069490792,
            "z": 241834226,
            "name": "ID",
            "country": "Indonesia"
          },
          {
            "x": 4234.979573,
            "y": 4.462644238,
            "z": 1234281163,
            "name": "IN",
            "country": "India"
          },
          {
            "x": 53725.0336,
            "y": 0.102064369,
            "z": 4554330,
            "name": "IE",
            "country": "Ireland"
          },
          {
            "x": 13805.70382,
            "y": 23.05756421,
            "z": 73762519,
            "name": "IR",
            "country": "Iran"
          },
          {
            "x": 8748.508776,
            "y": 42.61711161,
            "z": 29741977,
            "name": "IQ",
            "country": "Iraq"
          },
          {
            "x": 47457.62292,
            "y": 0,
            "z": 320342,
            "name": "IS",
            "country": "Iceland"
          },
          {
            "x": 34800.24747,
            "y": 0.168804761,
            "z": 7346446,
            "name": "IL",
            "country": "Israel"
          },
          {
            "x": 42664.35527,
            "y": 0.124141138,
            "z": 59325232,
            "name": "IT",
            "country": "Italy"
          },
          {
            "x": 9435.760842,
            "y": 1.42633119,
            "z": 2810464,
            "name": "JM",
            "country": "Jamaica"
          },
          {
            "x": 11315.5027,
            "y": 1.662046465,
            "z": 7261541,
            "name": "JO",
            "country": "Jordan"
          },
          {
            "x": 37586.16715,
            "y": 0.019088241,
            "z": 128542349,
            "name": "JP",
            "country": "Japan"
          },
          {
            "x": 20751.25724,
            "y": 24.21277147,
            "z": 16252273,
            "name": "KZ",
            "country": "Kazakhstan"
          },
          {
            "x": 3329.853752,
            "y": 2.656441074,
            "z": 42030684,
            "name": "KE",
            "country": "Kenya"
          },
          {
            "x": 4141.077206,
            "y": 9.8872718,
            "z": 5422298,
            "name": "KG",
            "country": "Kyrgyz Republic"
          },
          {
            "x": 2716.699738,
            "y": 2.695956615,
            "z": 14312205,
            "name": "KH",
            "country": "Cambodia"
          },
          {
            "x": 1923.107776,
            "y": 0.062338318,
            "z": 102930,
            "name": "KI",
            "country": "Kiribati"
          },
          {
            "x": 23710.3475,
            "y": 0,
            "z": 49011,
            "name": "KN",
            "country": "St. Kitts and Nevis"
          },
          {
            "x": 34394.49049,
            "y": 0.03246536,
            "z": 49545638,
            "name": "KR",
            "country": "South Korea"
          },
          {
            "x": 58810.40487,
            "y": 49.22719017,
            "z": 2991884,
            "name": "KW",
            "country": "Kuwait"
          },
          {
            "x": 4850.175067,
            "y": 14.81321484,
            "z": 6249168,
            "name": "LA",
            "country": "Laos"
          },
          {
            "x": 19499.1728,
            "y": 0.001880799,
            "z": 4953064,
            "name": "LB",
            "country": "Lebanon"
          },
          {
            "x": 1420.046246,
            "y": 18.36466184,
            "z": 3891357,
            "name": "LR",
            "country": "Liberia"
          },
          {
            "x": 22539.89276,
            "y": 57.08314963,
            "z": 6197667,
            "name": "LY",
            "country": "Libya"
          },
          {
            "x": 14109.41343,
            "y": 0.021393996,
            "z": 174092,
            "name": "LC",
            "country": "St. Lucia"
          },
          {
            "x": 9126.865612,
            "y": 0.187351776,
            "z": 20261738,
            "name": "LK",
            "country": "Sri Lanka"
          },
          {
            "x": 2346.713297,
            "y": 3.934399689,
            "z": 1995575,
            "name": "LS",
            "country": "Lesotho"
          },
          {
            "x": 23942.76036,
            "y": 0.547441868,
            "z": 3123825,
            "name": "LT",
            "country": "Lithuania"
          },
          {
            "x": 107703.4539,
            "y": 0.07299089,
            "z": 507890,
            "name": "LU",
            "country": "Luxembourg"
          },
          {
            "x": 21023.90133,
            "y": 1.219271632,
            "z": 2118855,
            "name": "LV",
            "country": "Latvia"
          },
          {
            "x": 118085.4875,
            "y": 0.000905336,
            "z": 538215,
            "name": "MO",
            "country": "Macau"
          },
          {
            "x": 6281.464191,
            "y": 5.523172003,
            "z": 32343384,
            "name": "MA",
            "country": "Morocco"
          },
          {
            "x": 8550.170639,
            "y": 0.138983107,
            "z": 4086090,
            "name": "MD",
            "country": "Moldova"
          },
          {
            "x": 1553.404722,
            "y": 5.808445004,
            "z": 21151640,
            "name": "MG",
            "country": "Madagascar"
          },
          {
            "x": 16305.79888,
            "y": 0.008965944,
            "z": 365730,
            "name": "MV",
            "country": "Maldives"
          },
          {
            "x": 17790.01192,
            "y": 4.881919008,
            "z": 114092961,
            "name": "MX",
            "country": "Mexico"
          },
          {
            "x": 3595.174776,
            "y": 0,
            "z": 56361,
            "name": "MH",
            "country": "Marshall Islands"
          },
          {
            "x": 13412.31283,
            "y": 2.611232541,
            "z": 2070737,
            "name": "MK",
            "country": "Macedonia"
          },
          {
            "x": 2082.961935,
            "y": 7.669752347,
            "z": 15049352,
            "name": "ML",
            "country": "Mali"
          },
          {
            "x": 32867.94003,
            "y": 0,
            "z": 414257,
            "name": "MT",
            "country": "Malta"
          },
          {
            "x": 3129.920255,
            "y": 0.044262226,
            "z": 50600827,
            "name": "MM",
            "country": "Myanmar"
          },
          {
            "x": 16764.36237,
            "y": 1.149530682,
            "z": 624279,
            "name": "ME",
            "country": "Montenegro"
          },
          {
            "x": 7479.780902,
            "y": 35.98066235,
            "z": 2719902,
            "name": "MN",
            "country": "Mongolia"
          },
          {
            "x": 1027.208877,
            "y": 11.09955773,
            "z": 23531567,
            "name": "MZ",
            "country": "Mozambique"
          },
          {
            "x": 4767.377366,
            "y": 33.38793282,
            "z": 3494200,
            "name": "MR",
            "country": "Mauritania"
          },
          {
            "x": 16797.81724,
            "y": 0.0068319,
            "z": 1247953,
            "name": "MU",
            "country": "Mauritius"
          },
          {
            "x": 1350.59917,
            "y": 5.943367884,
            "z": 14539609,
            "name": "MW",
            "country": "Malawi"
          },
          {
            "x": 20536.37251,
            "y": 9.440043346,
            "z": 28208028,
            "name": "MY",
            "country": "Malaysia"
          },
          {
            "x": 9031.160594,
            "y": 2.39089689,
            "z": 2118877,
            "name": "NA",
            "country": "Namibia"
          },
          {
            "x": 1036.904305,
            "y": 6.884721329,
            "z": 16464025,
            "name": "NE",
            "country": "Niger"
          },
          {
            "x": 4932.3348,
            "y": 14.77818265,
            "z": 158503203,
            "name": "NG",
            "country": "Nigeria"
          },
          {
            "x": 4611.785692,
            "y": 4.127939033,
            "z": 5824058,
            "name": "NI",
            "country": "Nicaragua"
          },
          {
            "x": 52032.9865,
            "y": 0.811320184,
            "z": 16682927,
            "name": "NL",
            "country": "Netherlands"
          },
          {
            "x": 61353.49639,
            "y": 8.899356086,
            "z": 4885878,
            "name": "NO",
            "country": "Norway"
          },
          {
            "x": 2703.414917,
            "y": 1.472314254,
            "z": 27013207,
            "name": "NP",
            "country": "Nepal"
          },
          {
            "x": 6688.649739,
            "y": 0,
            "z": 10009,
            "name": "NR",
            "country": "Nauru"
          },
          {
            "x": 37657.1432,
            "y": 2.109604367,
            "z": 4370060,
            "name": "NZ",
            "country": "New Zealand"
          },
          {
            "x": 33864.98374,
            "y": 39.57456469,
            "z": 3041435,
            "name": "OM",
            "country": "Oman"
          },
          {
            "x": 3906.873971,
            "y": 1.906288355,
            "z": 179424643,
            "name": "PK",
            "country": "Pakistan"
          },
          {
            "x": 21343.30499,
            "y": 0.234720391,
            "z": 3642691,
            "name": "PA",
            "country": "Panama"
          },
          {
            "x": 10066.46757,
            "y": 11.23352043,
            "z": 29027680,
            "name": "PE",
            "country": "Peru"
          },
          {
            "x": 5918.373229,
            "y": 2.225151923,
            "z": 93966784,
            "name": "PH",
            "country": "Philippines"
          },
          {
            "x": 15062.49579,
            "y": 0,
            "z": 17954,
            "name": "PW",
            "country": "Palau"
          },
          {
            "x": 3406.64404,
            "y": 27.26378708,
            "z": 7310512,
            "name": "PG",
            "country": "Papua New Guinea"
          },
          {
            "x": 23996.13978,
            "y": 4.311941074,
            "z": 38329784,
            "name": "PL",
            "country": "Poland"
          },
          {
            "x": 32960.69111,
            "y": 0,
            "z": 3579842,
            "name": "PR",
            "country": "Puerto Rico"
          },
          {
            "x": 31798.15381,
            "y": 0.18553083,
            "z": 10596055,
            "name": "PT",
            "country": "Portugal"
          },
          {
            "x": 10415.65644,
            "y": 1.940701065,
            "z": 6248017,
            "name": "PY",
            "country": "Paraguay"
          },
          {
            "x": 5411.066482,
            "y": 0,
            "z": 4055632,
            "name": "PS",
            "country": "Palestine"
          },
          {
            "x": 95908.31282,
            "y": 30.62219008,
            "z": 1856329,
            "name": "QA",
            "country": "Qatar"
          },
          {
            "x": 20303.1628,
            "y": 1.9111646,
            "z": 20471860,
            "name": "RO",
            "country": "Romania"
          },
          {
            "x": 23961.22029,
            "y": 15.55233041,
            "z": 143479273,
            "name": "RU",
            "country": "Russia"
          },
          {
            "x": 1507.16501,
            "y": 6.486188141,
            "z": 10039338,
            "name": "RW",
            "country": "Rwanda"
          },
          {
            "x": 44036.76735,
            "y": 39.83923892,
            "z": 27421468,
            "name": "SA",
            "country": "Saudi Arabia"
          },
          {
            "x": 3089.572476,
            "y": 15.70993899,
            "z": 34545014,
            "name": "SD",
            "country": "Sudan"
          },
          {
            "x": 2797.11016,
            "y": 2.982739694,
            "z": 12678143,
            "name": "SN",
            "country": "Senegal"
          },
          {
            "x": 78294.03142,
            "y": 0.000453217,
            "z": 5131170,
            "name": "SG",
            "country": "Singapore"
          },
          {
            "x": 2439.862325,
            "y": 16.72027211,
            "z": 527861,
            "name": "SB",
            "country": "Solomon Islands"
          },
          {
            "x": 1413.563736,
            "y": 10.52886611,
            "z": 6415636,
            "name": "SL",
            "country": "Sierra Leone"
          },
          {
            "x": 7328.71991,
            "y": 1.028742159,
            "z": 6183877,
            "name": "SV",
            "country": "El Salvador"
          },
          {
            "x": 72038.11362,
            "y": 0,
            "z": 31221,
            "name": "SM",
            "country": "San Marino"
          },
          {
            "x": 0,
            "y": 0,
            "z": 12043886,
            "name": "SO",
            "country": "Somalia"
          },
          {
            "x": 14510.9633,
            "y": 2.645032703,
            "z": 8991258,
            "name": "RS",
            "country": "Serbia"
          },
          {
            "x": 3357.470193,
            "y": 3.974413658,
            "z": 180372,
            "name": "ST",
            "country": "Sao Tome and Principe"
          },
          {
            "x": 18840.36897,
            "y": 22.21230832,
            "z": 529126,
            "name": "SR",
            "country": "Suriname"
          },
          {
            "x": 25417.81236,
            "y": 0.340991881,
            "z": 5404293,
            "name": "SK",
            "country": "Slovakia"
          },
          {
            "x": 33355.84763,
            "y": 0.304095448,
            "z": 2043336,
            "name": "SI",
            "country": "Slovenia"
          },
          {
            "x": 47791.37152,
            "y": 1.393800178,
            "z": 9390157,
            "name": "SE",
            "country": "Sweden"
          },
          {
            "x": 7459.227976,
            "y": 2.219395672,
            "z": 1064841,
            "name": "SZ",
            "country": "Eswatini"
          },
          {
            "x": 43543.88976,
            "y": 0,
            "z": 34166,
            "name": "SX",
            "country": "Sint Maarten"
          },
          {
            "x": 20892.69175,
            "y": 0.14695393,
            "z": 91273,
            "name": "SC",
            "country": "Seychelles"
          },
          {
            "x": 0,
            "y": 0.0047019,
            "z": 32658,
            "name": "TC",
            "country": "Turks and Caicos Islands"
          },
          {
            "x": 1732.691584,
            "y": 24.84248024,
            "z": 11952134,
            "name": "TD",
            "country": "Chad"
          },
          {
            "x": 1625.545446,
            "y": 11.30762831,
            "z": 6421674,
            "name": "TG",
            "country": "Togo"
          },
          {
            "x": 14399.04451,
            "y": 2.684025401,
            "z": 67195032,
            "name": "TH",
            "country": "Thailand"
          },
          {
            "x": 2390.022174,
            "y": 1.756350412,
            "z": 7527397,
            "name": "TJ",
            "country": "Tajikistan"
          },
          {
            "x": 8616.889533,
            "y": 30.43236481,
            "z": 5087211,
            "name": "TM",
            "country": "Turkmenistan"
          },
          {
            "x": 2930.054491,
            "y": 0,
            "z": 1093517,
            "name": "TL",
            "country": "Timor-Leste"
          },
          {
            "x": 5166.932054,
            "y": 0.048507618,
            "z": 103981,
            "name": "TO",
            "country": "Tonga"
          },
          {
            "x": 28879.28737,
            "y": 13.56029709,
            "z": 1328144,
            "name": "TT",
            "country": "Trinidad and Tobago"
          },
          {
            "x": 10113.37035,
            "y": 5.75669105,
            "z": 10635245,
            "name": "TN",
            "country": "Tunisia"
          },
          {
            "x": 20027.66683,
            "y": 1.043673636,
            "z": 72326992,
            "name": "TR",
            "country": "Turkey"
          },
          {
            "x": 3281.502177,
            "y": 0,
            "z": 10521,
            "name": "TV",
            "country": "Tuvalu"
          },
          {
            "x": 2006.971326,
            "y": 5.631015837,
            "z": 44346532,
            "name": "TZ",
            "country": "Tanzania"
          },
          {
            "x": 1861.282458,
            "y": 8.102294032,
            "z": 32428164,
            "name": "UG",
            "country": "Uganda"
          },
          {
            "x": 11778.3137,
            "y": 7.323926964,
            "z": 45792086,
            "name": "UA",
            "country": "Ukraine"
          },
          {
            "x": 19293.7408,
            "y": 2.004365053,
            "z": 3359273,
            "name": "UY",
            "country": "Uruguay"
          },
          {
            "x": 54315.91248,
            "y": 0.995556444,
            "z": 309011469,
            "name": "US",
            "country": "United States"
          },
          {
            "x": 4651.522962,
            "y": 17.05349996,
            "z": 28515908,
            "name": "UZ",
            "country": "Uzbekistan"
          },
          {
            "x": 11447.46662,
            "y": 0.03528671,
            "z": 108260,
            "name": "VC",
            "country": "St. Vincent and the Grenadines"
          },
          {
            "x": 5089.411016,
            "y": 9.593819919,
            "z": 87967655,
            "name": "VN",
            "country": "Vietnam"
          },
          {
            "x": 3088.978879,
            "y": 0.832394624,
            "z": 236216,
            "name": "VU",
            "country": "Vanuatu"
          },
          {
            "x": 6006.383728,
            "y": 0.42117737,
            "z": 185944,
            "name": "WS",
            "country": "Samoa"
          },
          {
            "x": 12452.33753,
            "y": 6.174865682,
            "z": 51216967,
            "name": "ZA",
            "country": "South Africa"
          },
          {
            "x": 3125.528849,
            "y": 18.66471996,
            "z": 13605986,
            "name": "ZM",
            "country": "Zambia"
          },
          {
            "x": 2458.220626,
            "y": 7.103586221,
            "z": 12697728,
            "name": "ZW",
            "country": "Zimbabwe"
          }
         ]
    }]

});
