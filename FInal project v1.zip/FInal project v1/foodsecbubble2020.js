

Highcharts.chart('container', {

    chart: {
        type: 'bubble',
        plotBorderWidth: 1,
        zoomType: 'xy'
    },

    legend: {
        enabled: false
    },

    title: {
        text: 'Food Security against GDP per capita 2020'
    },

    subtitle: {
        text: 'Sources: <a href="https://ourworldindata.org/grapher/gdp-per-capita-worldbank">GDP: OWID</a> , <a href="https://impact.economist.com/sustainability/project/food-security-index/">Food Security: Economist</a> , <a href="https://ourworldindata.org/grapher/population-past-future">Population: OWID</a>'
    },

    accessibility: {
        point: {
            valueDescriptionFormat: '{index}. {point.name}, $: {point.x}%, sugar: {point.y}%, obesity: {point.z}.'
        }
    },

    xAxis: {
        gridLineWidth: 1,
        title: {
            text: 'GDP Per Capita'
        },
        labels: {
            format: '{value} $'
        },
        plotLines: [{
            color: '',
            dashStyle: '',
            width: 0,
            value: 0,
            label: {
                rotation: 0,
                y: 0,
                style: {
                    fontStyle: 'italic'
                },
                text: ''
            },
            zIndex: 3
        }],
        accessibility: {
            rangeDescription: 'Range: 60 to 100 grams.'
        }
    },

    yAxis: {
        startOnTick: false,
        endOnTick: false,
        title: {
            text: 'Food Security %'
        },
        labels: {
            format: '{value} %'
        },
        maxPadding: 0.2,
        plotLines: [{
            color: '',
            dashStyle: '',
            width: 0,
            value: 0,
            label: {
                align: 'right',
                style: {
                    fontStyle: 'italic'
                },
                text: '',
                x: 0
            },
            zIndex: 3
        }],
        accessibility: {
            rangeDescription: 'Range: 0 to 160 grams.'
        }
    },

    tooltip: {
        useHTML: true,
        headerFormat: '<table>',
        pointFormat: '<tr><th colspan="2"><h3>{point.country}</h3></th></tr>' +
            '<tr><th>GDP Per Capita:</th><td>{point.x}$</td></tr>' +
            '<tr><th>Food Security:</th><td>{point.y}%</td></tr>' +
            '<tr><th>Population:</th><td>{point.z}</td></tr>',
        footerFormat: '</table>',
        followPointer: true
    },

    plotOptions: {
        series: {
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },

    series: [{
        color: '#FF0000',
        data:[
          {
            "x": 6198.083841,
            "y": 41.7,
            "z": 32866267,
            "name": "AO",
            "country": "Angola"
          },
          {
            "x": 0,
            "y": 71.4,
            "z": 9890400,
            "name": "AE",
            "country": "United Arab Emirates"
          },
          {
            "x": 19686.52366,
            "y": 63.1,
            "z": 45195777,
            "name": "AR",
            "country": "Argentina"
          },
          {
            "x": 48697.83703,
            "y": 73.9,
            "z": 25499881,
            "name": "AU",
            "country": "Australia"
          },
          {
            "x": 51935.60386,
            "y": 80.1,
            "z": 9006400,
            "name": "AT",
            "country": "Austria"
          },
          {
            "x": 13699.66559,
            "y": 61.5,
            "z": 10139175,
            "name": "AZ",
            "country": "Azerbaijan"
          },
          {
            "x": 731.0632297,
            "y": 38,
            "z": 11890781,
            "name": "BI",
            "country": "Burundi"
          },
          {
            "x": 48210.03311,
            "y": 76.9,
            "z": 11589616,
            "name": "BE",
            "country": "Belgium"
          },
          {
            "x": 3323.144451,
            "y": 46.1,
            "z": 12123198,
            "name": "BJ",
            "country": "Benin"
          },
          {
            "x": 2160.51153,
            "y": 46.8,
            "z": 20903278,
            "name": "BF",
            "country": "Burkina Faso"
          },
          {
            "x": 4818.094737,
            "y": 50.5,
            "z": 164689383,
            "name": "BD",
            "country": "Bangladesh"
          },
          {
            "x": 22383.80554,
            "y": 68.7,
            "z": 6948445,
            "name": "BG",
            "country": "Bulgaria"
          },
          {
            "x": 40933.35266,
            "y": 68.4,
            "z": 1701583,
            "name": "BH",
            "country": "Bahrain"
          },
          {
            "x": 19148.1751,
            "y": 70.4,
            "z": 9449321,
            "name": "BY",
            "country": "Belarus"
          },
          {
            "x": 7931.754309,
            "y": 59,
            "z": 11673029,
            "name": "BO",
            "country": "Bolivia"
          },
          {
            "x": 14063.98251,
            "y": 62.8,
            "z": 212559409,
            "name": "BR",
            "country": "Brazil"
          },
          {
            "x": 16040.00847,
            "y": 56.1,
            "z": 2351625,
            "name": "BW",
            "country": "Botswana"
          },
          {
            "x": 45856.62563,
            "y": 78,
            "z": 37742157,
            "name": "CA",
            "country": "Canada"
          },
          {
            "x": 68393.306,
            "y": 80.2,
            "z": 8654618,
            "name": "CH",
            "country": "Switzerland"
          },
          {
            "x": 23324.52475,
            "y": 72.1,
            "z": 19116209,
            "name": "CL",
            "country": "Chile"
          },
          {
            "x": 16410.7978,
            "y": 70.9,
            "z": 1439323774,
            "name": "CN",
            "country": "China"
          },
          {
            "x": 5174.100553,
            "y": 50.4,
            "z": 26378275,
            "name": "CI",
            "country": "Cote d'Ivoire"
          },
          {
            "x": 3576.349499,
            "y": 43.9,
            "z": 26545864,
            "name": "CM",
            "country": "Cameroon"
          },
          {
            "x": 1072.210113,
            "y": 38.1,
            "z": 89561404,
            "name": "CD",
            "country": "DR Congo"
          },
          {
            "x": 13441.49295,
            "y": 60.5,
            "z": 50882884,
            "name": "CO",
            "country": "Colombia"
          },
          {
            "x": 19679.28864,
            "y": 71.4,
            "z": 5094114,
            "name": "CR",
            "country": "Costa Rica"
          },
          {
            "x": 38319.33766,
            "y": 78.8,
            "z": 10708982,
            "name": "CZ",
            "country": "Czech Republic"
          },
          {
            "x": 50922.35802,
            "y": 79.6,
            "z": 83783945,
            "name": "DE",
            "country": "Germany"
          },
          {
            "x": 55938.21281,
            "y": 76.7,
            "z": 5792203,
            "name": "DK",
            "country": "Denmark"
          },
          {
            "x": 17003.01302,
            "y": 66.2,
            "z": 10847904,
            "name": "DO",
            "country": "Dominican Republic"
          },
          {
            "x": 10681.6793,
            "y": 61.6,
            "z": 43851043,
            "name": "DZ",
            "country": "Algeria"
          },
          {
            "x": 10329.19875,
            "y": 58.9,
            "z": 17643060,
            "name": "EC",
            "country": "Ecuador"
          },
          {
            "x": 11951.44753,
            "y": 59.8,
            "z": 102334403,
            "name": "EG",
            "country": "Egypt"
          },
          {
            "x": 36215.44759,
            "y": 74.8,
            "z": 46754783,
            "name": "ES",
            "country": "Spain"
          },
          {
            "x": 2296.827352,
            "y": 36.7,
            "z": 114963583,
            "name": "ET",
            "country": "Ethiopia"
          },
          {
            "x": 47260.80046,
            "y": 85.2,
            "z": 5540718,
            "name": "FI",
            "country": "Finland"
          },
          {
            "x": 42025.61737,
            "y": 78.4,
            "z": 65273512,
            "name": "FR",
            "country": "France"
          },
          {
            "x": 41627.12927,
            "y": 80.6,
            "z": 67886004,
            "name": "GB",
            "country": "United Kingdom"
          },
          {
            "x": 5304.983525,
            "y": 52.8,
            "z": 31072945,
            "name": "GH",
            "country": "Ghana"
          },
          {
            "x": 2670.823355,
            "y": 42.8,
            "z": 13132792,
            "name": "GN",
            "country": "Guinea"
          },
          {
            "x": 27287.0834,
            "y": 74.1,
            "z": 10423056,
            "name": "GR",
            "country": "Greece"
          },
          {
            "x": 8393.284643,
            "y": 55.1,
            "z": 17915567,
            "name": "GT",
            "country": "Guatemala"
          },
          {
            "x": 5138.385398,
            "y": 58.1,
            "z": 9904608,
            "name": "HN",
            "country": "Honduras"
          },
          {
            "x": 2773.081364,
            "y": 35.7,
            "z": 11402533,
            "name": "HT",
            "country": "Haiti"
          },
          {
            "x": 31007.76841,
            "y": 72,
            "z": 9660350,
            "name": "HU",
            "country": "Hungary"
          },
          {
            "x": 11444.96068,
            "y": 61.4,
            "z": 273523621,
            "name": "ID",
            "country": "Indonesia"
          },
          {
            "x": 6118.35733,
            "y": 58.6,
            "z": 1380004385,
            "name": "IN",
            "country": "India"
          },
          {
            "x": 89688.95696,
            "y": 84.5,
            "z": 4937796,
            "name": "IE",
            "country": "Ireland"
          },
          {
            "x": 38341.30757,
            "y": 78.1,
            "z": 8655541,
            "name": "IL",
            "country": "Israel"
          },
          {
            "x": 38992.14838,
            "y": 76.5,
            "z": 60461828,
            "name": "IT",
            "country": "Italy"
          },
          {
            "x": 9816.55453,
            "y": 64.9,
            "z": 10203140,
            "name": "JO",
            "country": "Jordan"
          },
          {
            "x": 0,
            "y": 80.3,
            "z": 126476458,
            "name": "JP",
            "country": "Japan"
          },
          {
            "x": 25337.1524,
            "y": 71.9,
            "z": 18776707,
            "name": "KZ",
            "country": "Kazakhstan"
          },
          {
            "x": 4220.440248,
            "y": 46.7,
            "z": 53771300,
            "name": "KE",
            "country": "Kenya"
          },
          {
            "x": 4191.850003,
            "y": 51.3,
            "z": 16718971,
            "name": "KH",
            "country": "Cambodia"
          },
          {
            "x": 42251.44506,
            "y": 73.4,
            "z": 51269183,
            "name": "KR",
            "country": "South Korea"
          },
          {
            "x": 0,
            "y": 72.9,
            "z": 4270563,
            "name": "KW",
            "country": "Kuwait"
          },
          {
            "x": 7805.798556,
            "y": 51,
            "z": 7275556,
            "name": "LA",
            "country": "Laos"
          },
          {
            "x": 12536.94176,
            "y": 57.1,
            "z": 21413250,
            "name": "LK",
            "country": "Sri Lanka"
          },
          {
            "x": 6916.346412,
            "y": 62.1,
            "z": 36910558,
            "name": "MA",
            "country": "Morocco"
          },
          {
            "x": 1510.141726,
            "y": 38,
            "z": 27691019,
            "name": "MG",
            "country": "Madagascar"
          },
          {
            "x": 17887.75074,
            "y": 66.1,
            "z": 128932753,
            "name": "MX",
            "country": "Mexico"
          },
          {
            "x": 2216.773262,
            "y": 52.7,
            "z": 20250834,
            "name": "ML",
            "country": "Mali"
          },
          {
            "x": 4544.021569,
            "y": 54,
            "z": 54409794,
            "name": "MM",
            "country": "Myanmar"
          },
          {
            "x": 1229.080019,
            "y": 37.2,
            "z": 31255435,
            "name": "MZ",
            "country": "Mozambique"
          },
          {
            "x": 1486.778248,
            "y": 39.1,
            "z": 19129955,
            "name": "MW",
            "country": "Malawi"
          },
          {
            "x": 26435.17157,
            "y": 65,
            "z": 32365998,
            "name": "MY",
            "country": "Malaysia"
          },
          {
            "x": 1196.87756,
            "y": 49.9,
            "z": 24206636,
            "name": "NE",
            "country": "Niger"
          },
          {
            "x": 4916.721381,
            "y": 41.2,
            "z": 206139587,
            "name": "NG",
            "country": "Nigeria"
          },
          {
            "x": 5280.140581,
            "y": 53,
            "z": 6624554,
            "name": "NI",
            "country": "Nicaragua"
          },
          {
            "x": 54209.56384,
            "y": 80,
            "z": 17134873,
            "name": "NL",
            "country": "Netherlands"
          },
          {
            "x": 63585.90351,
            "y": 78.5,
            "z": 5421242,
            "name": "NO",
            "country": "Norway"
          },
          {
            "x": 3800.065703,
            "y": 54.8,
            "z": 29136808,
            "name": "NP",
            "country": "Nepal"
          },
          {
            "x": 42404.39374,
            "y": 77.7,
            "z": 4822233,
            "name": "NZ",
            "country": "New Zealand"
          },
          {
            "x": 0,
            "y": 70.5,
            "z": 5106622,
            "name": "OM",
            "country": "Oman"
          },
          {
            "x": 4622.770769,
            "y": 55.7,
            "z": 220892331,
            "name": "PK",
            "country": "Pakistan"
          },
          {
            "x": 25381.84845,
            "y": 72.8,
            "z": 4314768,
            "name": "PA",
            "country": "Panama"
          },
          {
            "x": 11260.84575,
            "y": 66.2,
            "z": 32971845,
            "name": "PE",
            "country": "Peru"
          },
          {
            "x": 7953.581644,
            "y": 61,
            "z": 109581085,
            "name": "PH",
            "country": "Philippines"
          },
          {
            "x": 32238.15726,
            "y": 75.2,
            "z": 37846605,
            "name": "PL",
            "country": "Poland"
          },
          {
            "x": 32181.15454,
            "y": 76.5,
            "z": 10196707,
            "name": "PT",
            "country": "Portugal"
          },
          {
            "x": 12335.47236,
            "y": 60.4,
            "z": 7132530,
            "name": "PY",
            "country": "Paraguay"
          },
          {
            "x": 85266.21059,
            "y": 73.7,
            "z": 2881060,
            "name": "QA",
            "country": "Qatar"
          },
          {
            "x": 28832.62315,
            "y": 73.8,
            "z": 19237682,
            "name": "RO",
            "country": "Romania"
          },
          {
            "x": 26456.38794,
            "y": 73.9,
            "z": 145934460,
            "name": "RU",
            "country": "Russia"
          },
          {
            "x": 2098.710362,
            "y": 45.2,
            "z": 12952209,
            "name": "RW",
            "country": "Rwanda"
          },
          {
            "x": 44328.18391,
            "y": 71.5,
            "z": 34813867,
            "name": "SA",
            "country": "Saudi Arabia"
          },
          {
            "x": 4022.865967,
            "y": 36.4,
            "z": 43849269,
            "name": "SD",
            "country": "Sudan"
          },
          {
            "x": 3300.085493,
            "y": 45.5,
            "z": 16743930,
            "name": "SN",
            "country": "Senegal"
          },
          {
            "x": 93397.0488,
            "y": 78.3,
            "z": 5850343,
            "name": "SG",
            "country": "Singapore"
          },
          {
            "x": 1648.05336,
            "y": 39.8,
            "z": 7976985,
            "name": "SL",
            "country": "Sierra Leone"
          },
          {
            "x": 8056.543086,
            "y": 57.8,
            "z": 6486201,
            "name": "SV",
            "country": "El Salvador"
          },
          {
            "x": 18210.00462,
            "y": 61.2,
            "z": 8737370,
            "name": "RS",
            "country": "Serbia"
          },
          {
            "x": 30330.04289,
            "y": 68.1,
            "z": 5459643,
            "name": "SK",
            "country": "Slovakia"
          },
          {
            "x": 50683.32351,
            "y": 78.3,
            "z": 10099270,
            "name": "SE",
            "country": "Sweden"
          },
          {
            "x": 1519.912362,
            "y": 41.7,
            "z": 16425859,
            "name": "TD",
            "country": "Chad"
          },
          {
            "x": 2107.877261,
            "y": 45.7,
            "z": 8278736,
            "name": "TG",
            "country": "Togo"
          },
          {
            "x": 17286.86661,
            "y": 63.6,
            "z": 69799978,
            "name": "TH",
            "country": "Thailand"
          },
          {
            "x": 3657.573507,
            "y": 52.5,
            "z": 9537642,
            "name": "TJ",
            "country": "Tajikistan"
          },
          {
            "x": 9727.504259,
            "y": 60.2,
            "z": 11818618,
            "name": "TN",
            "country": "Tunisia"
          },
          {
            "x": 28384.98778,
            "y": 61.2,
            "z": 84339067,
            "name": "TR",
            "country": "Turkey"
          },
          {
            "x": 2635.335891,
            "y": 47.7,
            "z": 59734213,
            "name": "TZ",
            "country": "Tanzania"
          },
          {
            "x": 2177.595854,
            "y": 43.2,
            "z": 45741000,
            "name": "UG",
            "country": "Uganda"
          },
          {
            "x": 12377.01729,
            "y": 58.8,
            "z": 43733759,
            "name": "UA",
            "country": "Ukraine"
          },
          {
            "x": 21608.43027,
            "y": 72.7,
            "z": 3473727,
            "name": "UY",
            "country": "Uruguay"
          },
          {
            "x": 60235.72849,
            "y": 80,
            "z": 331002647,
            "name": "US",
            "country": "United States"
          },
          {
            "x": 6994.169412,
            "y": 54.1,
            "z": 33469199,
            "name": "UZ",
            "country": "Uzbekistan"
          },
          {
            "x": 8200.331867,
            "y": 62.7,
            "z": 97338583,
            "name": "VN",
            "country": "Vietnam"
          },
          {
            "x": 11466.18967,
            "y": 58,
            "z": 59308690,
            "name": "ZA",
            "country": "South Africa"
          },
          {
            "x": 3270.035112,
            "y": 38.9,
            "z": 18383956,
            "name": "ZM",
            "country": "Zambia"
          }
         ]
    }]

});
