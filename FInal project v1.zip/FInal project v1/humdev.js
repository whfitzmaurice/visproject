$(function humdev() {
	var year = 1990;
	var start = 1990;
	var finish = 2019;
	var seriesPath = 'https://whfitzmaurice.github.io/visproject/humdev.json'




	localStorageTest();
	clearStorage();

	addMapMenuItems(start, finish);
	addSlider(start, finish, year);
	runSeries(start, finish, year);
	getMapSeries(year, seriesPath)


	function prepMapData(year){
		// Prepare data for the selected year and return it

		var allData = getObject('allData');
		var selectedData = [];
		// OECD series runs from 1980 =>

		for (var i=0; i<allData.length; i++){
			// need to generate: {"iso-a3": "xxx", "value": nnnnn}
			selectedData.push({"iso-a3":allData[i][0].iso3, "value":allData[i][0].data[year-1990]});
			//console.log({"iso-a3":allData[i][0].iso3, "value":allData[i][0].data[year-1980]});
		};
		//console.log(JSON.stringify(selectedData));
		return selectedData;
	};

	function drawMap(year, selectedData){
		// draw a single chart
		$('#displayarea2').highcharts('Map', {

			title: {
				text: 'Human Development '+year
			},

			subtitle: {
				text: 'Source: <a href="https://hdr.undp.org/en/content/human-development-index-hdi">Human Development Index: UNDP</a>'
			},

			mapNavigation: {
				enabled: true,
				buttonOptions: {
					verticalAlign: 'bottom'
				}
			},
			
			colorAxis: {
				min: 0,
				//max: 10000000000000, // set to give a consistent scale - can be removed to emphasise between-country differences
				minColor: '#FFFFFF',
				maxColor: '#000000',
			},

			series: [{
				data: selectedData,
				mapData: Highcharts.maps['custom/world-robinson'],
				joinBy: 'iso-a3',
				name: 'Percentage developed '+year,
				states: {
					hover: {
						color: 'palegreen'
					}
				},
				dataLabels: {
					enabled: false,
					format: '{point.name}'
				}
			}]
		});
	};

	function addMapMenuItems(start, finish){
		// populate the menu
		var startTag = '<input type="radio" name="selectYear"';
		var endTag = '</input>';
		$('#menubox2').empty();
		$('#menubox2').append('<h3>Year to display</h3>');
		$('#menubox2').append('<button type="button" id="yearListSelect">Display</button>');
		$('#menubox2').append('<br />');
	
		// add a listener to respond to a button click
		$('#yearListSelect').on( 'click', function() {
			$('#displayarea2').empty();
			var year = $('input[name="selectYear"]:checked').val();
			//console.log('84', year)
			selectedData = prepMapData(year);
			drawMap(year, selectedData);
		});
	
		// make a list of buttons in two columns
		for (i=start; i<=finish; i++){
			if (i%2){
				var button = startTag+'value="'+i+'">'+i+endTag+'<br />';
			} else {
				var button = startTag+'value="'+i+'">'+i+endTag;
			};
			$('#menubox2').append(button);
		};
	};

	function getMapSeries(year, seriesPath){
		// fetch the series data from the server or a local file
		//	and store it in local storage
		//console.log('getting series '+seriesPath);
		$.getJSON(seriesPath, function (data) {
			//console.log(seriesPath, JSON.stringify(data));
			clearObject('allData');
			setObject('allData', data);
			drawMap(year, prepMapData(year));
		})
		.fail(function(jqXHR, textStatus, errorThrown) { 
			console.log('getJSON request failed! ' + textStatus); 
		});	
	};
	
	function addSlider(start, finish, year) {
		console.log(start, finish, year);
		$('#sliderbox').empty();

		$('#sliderbox').append('<div id="slider"></div>');
		$('#sliderbox').append('<div id="sliderStartVal"></div>');
		$('#sliderbox').append('<div id="sliderEndVal"></div>');
		$('#sliderStartVal').append(start);
		$('#sliderEndVal').append(finish);

		$('#slider').append('<div id="custom-handle" class="ui-slider-handle"></div>');
		//$('#sliderbox').append(finish);
		var handle = $('#custom-handle');
		$('#slider').slider({
			min: start,
			max: finish,
			value: year,
			create: function() {
				handle.text($(this).slider('value') );
			},
			slide: function(event, ui) {
				handle.text(ui.value);
				//console.log (ui.value);
				drawMap(ui.value, prepMapData(ui.value));
			}
		});		
	};

	function runSeries(start, finish){
		$('#sliderbox').append('<button type="button" id="runSeries">&gtcc;</button>');
		$('#runSeries').on('click', function() {
			var i = start;
			var intervalID = setInterval(function () {
				addSlider(start, finish, i);
				drawMap(i, prepMapData(i));
				i++;
				if (i > finish){
					clearInterval(intervalID);
					// need to put the runSeries button back at the end
					runSeries(start, finish);
				}
			}, 100);
		});
	
	};

	// button function
	

let optsWrapper = document.getElementById('options-wrapper').children; //buttons
	optsWrapper[0].classList.add('btn-active'); // may have to add to CSS / default selected

	for (let i = 0; i < optsWrapper.length; i++) {
		optsWrapper[i].addEventListener('click', (e) => {
			// toggle charts
			gdp(e.target.num || 0);
		});
	}
});