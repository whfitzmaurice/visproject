

Highcharts.chart('container', {

    chart: {
        type: 'bubble',
        plotBorderWidth: 1,
        zoomType: 'xy'
    },

    legend: {
        enabled: false
    },

    title: {
        text: 'Political Stability against GDP per capita 2020'
    },

    subtitle: {
        text: 'Sources: <a href="https://ourworldindata.org/grapher/gdp-per-capita-worldbank">GDP: OWID</a> , <a href="https://tcdata360.worldbank.org/indicators/h395cb858?country=BRA&indicator=376&viz=line_chart&years=1996,2020">Political Stability: World Bank</a> , <a href="https://ourworldindata.org/grapher/population-past-future">Population: OWID</a>'
    },

    accessibility: {
        point: {
            valueDescriptionFormat: '{index}. {point.name}, $: {point.x}%, sugar: {point.y}%, obesity: {point.z}.'
        }
    },

    xAxis: {
        gridLineWidth: 1,
        title: {
            text: 'GDP Per Capita'
        },
        labels: {
            format: '{value} $'
        },
        plotLines: [{
            color: '',
            dashStyle: '',
            width: 0,
            value: 0,
            label: {
                rotation: 0,
                y: 0,
                style: {
                    fontStyle: 'italic'
                },
                text: ''
            },
            zIndex: 3
        }],
        accessibility: {
            rangeDescription: 'Range: 60 to 100 grams.'
        }
    },

    yAxis: {
        startOnTick: false,
        endOnTick: false,
        title: {
            text: 'Political Stability %'
        },
        labels: {
            format: '{value} %'
        },
        maxPadding: 0.2,
        plotLines: [{
            color: '',
            dashStyle: '',
            width: 0,
            value: 0,
            label: {
                align: 'right',
                style: {
                    fontStyle: 'italic'
                },
                text: '',
                x: 0
            },
            zIndex: 3
        }],
        accessibility: {
            rangeDescription: 'Range: 0 to 160 grams.'
        }
    },

    tooltip: {
        useHTML: true,
        headerFormat: '<table>',
        pointFormat: '<tr><th colspan="2"><h3>{point.country}</h3></th></tr>' +
            '<tr><th>GDP Per Capita:</th><td>{point.x}$</td></tr>' +
            '<tr><th>Political Stability:</th><td>{point.y}%</td></tr>' +
            '<tr><th>Population:</th><td>{point.z}</td></tr>',
        footerFormat: '</table>',
        followPointer: true
    },

    plotOptions: {
        series: {
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },

    series: [{
        color: '#0e2f44',

        data:[
          {
            "x": 0,
            "y": 96.22642,
            "z": 106766,
            "name": "AW",
            "country": "Aruba"
          },
          {
            "x": 1978.961579,
            "y": 0.4716981,
            "z": 38928341,
            "name": "AF",
            "country": "Afghanistan"
          },
          {
            "x": 6198.083841,
            "y": 26.88679,
            "z": 32866267,
            "name": "AO",
            "country": "Angola"
          },
          {
            "x": 13295.41088,
            "y": 49.5283,
            "z": 2877800,
            "name": "AL",
            "country": "Albania"
          },
          {
            "x": 0,
            "y": 66.03773,
            "z": 9890400,
            "name": "AE",
            "country": "United Arab Emirates"
          },
          {
            "x": 19686.52366,
            "y": 48.58491,
            "z": 45195777,
            "name": "AR",
            "country": "Argentina"
          },
          {
            "x": 12592.63537,
            "y": 25.9434,
            "z": 2963234,
            "name": "AM",
            "country": "Armenia"
          },
          {
            "x": 17956.31572,
            "y": 80.18868,
            "z": 97928,
            "name": "AG",
            "country": "Antigua and Barbuda"
          },
          {
            "x": 48697.83703,
            "y": 73.1132,
            "z": 25499881,
            "name": "AU",
            "country": "Australia"
          },
          {
            "x": 51935.60386,
            "y": 74.52831,
            "z": 9006400,
            "name": "AT",
            "country": "Austria"
          },
          {
            "x": 13699.66559,
            "y": 21.69811,
            "z": 10139175,
            "name": "AZ",
            "country": "Azerbaijan"
          },
          {
            "x": 731.0632297,
            "y": 10.37736,
            "z": 11890781,
            "name": "BI",
            "country": "Burundi"
          },
          {
            "x": 48210.03311,
            "y": 64.62264,
            "z": 11589616,
            "name": "BE",
            "country": "Belgium"
          },
          {
            "x": 3323.144451,
            "y": 29.71698,
            "z": 12123198,
            "name": "BJ",
            "country": "Benin"
          },
          {
            "x": 2160.51153,
            "y": 8.490566,
            "z": 20903278,
            "name": "BF",
            "country": "Burkina Faso"
          },
          {
            "x": 4818.094737,
            "y": 16.03773,
            "z": 164689383,
            "name": "BD",
            "country": "Bangladesh"
          },
          {
            "x": 22383.80554,
            "y": 60.84906,
            "z": 6948445,
            "name": "BG",
            "country": "Bulgaria"
          },
          {
            "x": 40933.35266,
            "y": 25.4717,
            "z": 1701583,
            "name": "BH",
            "country": "Bahrain"
          },
          {
            "x": 30764.11597,
            "y": 73.58491,
            "z": 393248,
            "name": "BS",
            "country": "Bahamas"
          },
          {
            "x": 14339.83118,
            "y": 27.83019,
            "z": 3280815,
            "name": "BA",
            "country": "Bosnia and Herzegovina"
          },
          {
            "x": 19148.1751,
            "y": 21.22642,
            "z": 9449321,
            "name": "BY",
            "country": "Belarus"
          },
          {
            "x": 6119.887687,
            "y": 62.26415,
            "z": 397621,
            "name": "BZ",
            "country": "Belize"
          },
          {
            "x": 0,
            "y": 83.96227,
            "z": 62273,
            "name": "BM",
            "country": "Bermuda"
          },
          {
            "x": 7931.754309,
            "y": 28.77358,
            "z": 11673029,
            "name": "BO",
            "country": "Bolivia"
          },
          {
            "x": 14063.98251,
            "y": 32.07547,
            "z": 212559409,
            "name": "BR",
            "country": "Brazil"
          },
          {
            "x": 12870.0425,
            "y": 91.03773,
            "z": 287371,
            "name": "BB",
            "country": "Barbados"
          },
          {
            "x": 62243.58315,
            "y": 90.56604,
            "z": 437483,
            "name": "BN",
            "country": "Brunei Darussalam"
          },
          {
            "x": 10909.10017,
            "y": 84.90566,
            "z": 771612,
            "name": "BT",
            "country": "Bhutan"
          },
          {
            "x": 16040.00847,
            "y": 89.15094,
            "z": 2351625,
            "name": "BW",
            "country": "Botswana"
          },
          {
            "x": 928.5895075,
            "y": 2.830189,
            "z": 4829764,
            "name": "CF",
            "country": "Central African Republic"
          },
          {
            "x": 45856.62563,
            "y": 90.09434,
            "z": 37742157,
            "name": "CA",
            "country": "Canada"
          },
          {
            "x": 68393.306,
            "y": 93.39622,
            "z": 8654618,
            "name": "CH",
            "country": "Switzerland"
          },
          {
            "x": 23324.52475,
            "y": 49.0566,
            "z": 19116209,
            "name": "CL",
            "country": "Chile"
          },
          {
            "x": 16410.7978,
            "y": 37.73585,
            "z": 1439323774,
            "name": "CN",
            "country": "China"
          },
          {
            "x": 5174.100553,
            "y": 15.09434,
            "z": 26378275,
            "name": "CI",
            "country": "Cote d'Ivoire"
          },
          {
            "x": 3576.349499,
            "y": 8.962264,
            "z": 26545864,
            "name": "CM",
            "country": "Cameroon"
          },
          {
            "x": 1072.210113,
            "y": 7.075472,
            "z": 89561404,
            "name": "CD",
            "country": "DR Congo"
          },
          {
            "x": 3449.145695,
            "y": 16.50943,
            "z": 5518092,
            "name": "CG",
            "country": "Congo Republic"
          },
          {
            "x": 13441.49295,
            "y": 22.16981,
            "z": 50882884,
            "name": "CO",
            "country": "Colombia"
          },
          {
            "x": 3140.698772,
            "y": 37.26415,
            "z": 869595,
            "name": "KM",
            "country": "Comoros"
          },
          {
            "x": 6045.060885,
            "y": 77.35849,
            "z": 555988,
            "name": "CV",
            "country": "Cabo Verde"
          },
          {
            "x": 19679.28864,
            "y": 71.69811,
            "z": 5094114,
            "name": "CR",
            "country": "Costa Rica"
          },
          {
            "x": 0,
            "y": 98.1132,
            "z": 65720,
            "name": "KY",
            "country": "Cayman Islands"
          },
          {
            "x": 37655.18035,
            "y": 56.13208,
            "z": 1207361,
            "name": "CY",
            "country": "Cyprus"
          },
          {
            "x": 38319.33766,
            "y": 79.24529,
            "z": 10708982,
            "name": "CZ",
            "country": "Czech Republic"
          },
          {
            "x": 50922.35802,
            "y": 68.86793,
            "z": 83783945,
            "name": "DE",
            "country": "Germany"
          },
          {
            "x": 5481.114817,
            "y": 36.32076,
            "z": 988002,
            "name": "DJ",
            "country": "Djibouti"
          },
          {
            "x": 9891.29194,
            "y": 95.28302,
            "z": 71991,
            "name": "DM",
            "country": "Dominica"
          },
          {
            "x": 55938.21281,
            "y": 81.60378,
            "z": 5792203,
            "name": "DK",
            "country": "Denmark"
          },
          {
            "x": 17003.01302,
            "y": 52.35849,
            "z": 10847904,
            "name": "DO",
            "country": "Dominican Republic"
          },
          {
            "x": 10681.6793,
            "y": 17.45283,
            "z": 43851043,
            "name": "DZ",
            "country": "Algeria"
          },
          {
            "x": 10329.19875,
            "y": 34.43396,
            "z": 17643060,
            "name": "EC",
            "country": "Ecuador"
          },
          {
            "x": 11951.44753,
            "y": 11.32076,
            "z": 102334403,
            "name": "EG",
            "country": "Egypt"
          },
          {
            "x": 36215.44759,
            "y": 58.01887,
            "z": 46754783,
            "name": "ES",
            "country": "Spain"
          },
          {
            "x": 35638.42135,
            "y": 70.28302,
            "z": 1326539,
            "name": "EE",
            "country": "Estonia"
          },
          {
            "x": 2296.827352,
            "y": 6.603774,
            "z": 114963583,
            "name": "ET",
            "country": "Ethiopia"
          },
          {
            "x": 47260.80046,
            "y": 82.07547,
            "z": 5540718,
            "name": "FI",
            "country": "Finland"
          },
          {
            "x": 10997.47349,
            "y": 71.22642,
            "z": 896444,
            "name": "FJ",
            "country": "Fiji"
          },
          {
            "x": 42025.61737,
            "y": 56.60378,
            "z": 65273512,
            "name": "FR",
            "country": "France"
          },
          {
            "x": 0,
            "y": 88.20755,
            "z": 115021,
            "name": "FM",
            "country": "Micronesia, Fed. Sts."
          },
          {
            "x": 14399.86881,
            "y": 44.33962,
            "z": 2225728,
            "name": "GA",
            "country": "Gabon"
          },
          {
            "x": 41627.12927,
            "y": 61.32076,
            "z": 67886004,
            "name": "GB",
            "country": "United Kingdom"
          },
          {
            "x": 14089.30233,
            "y": 30.66038,
            "z": 3989175,
            "name": "GE",
            "country": "Georgia"
          },
          {
            "x": 5304.983525,
            "y": 51.88679,
            "z": 31072945,
            "name": "GH",
            "country": "Ghana"
          },
          {
            "x": 2670.823355,
            "y": 23.58491,
            "z": 13132792,
            "name": "GN",
            "country": "Guinea"
          },
          {
            "x": 2159.441909,
            "y": 55.18868,
            "z": 2416664,
            "name": "GM",
            "country": "Gambia"
          },
          {
            "x": 1847.465824,
            "y": 25,
            "z": 1967998,
            "name": "GW",
            "country": "Guinea-Bissau"
          },
          {
            "x": 17007.62478,
            "y": 41.98113,
            "z": 1402985,
            "name": "GQ",
            "country": "Equatorial Guinea"
          },
          {
            "x": 27287.0834,
            "y": 51.41509,
            "z": 10423056,
            "name": "GR",
            "country": "Greece"
          },
          {
            "x": 15065.87195,
            "y": 86.79245,
            "z": 112519,
            "name": "GD",
            "country": "Grenada"
          },
          {
            "x": 8393.284643,
            "y": 31.13208,
            "z": 17915567,
            "name": "GT",
            "country": "Guatemala"
          },
          {
            "x": 18679.98023,
            "y": 42.45283,
            "z": 786559,
            "name": "GY",
            "country": "Guyana"
          },
          {
            "x": 56153.9715,
            "y": 50,
            "z": 7496988,
            "name": "HK",
            "country": "Hong Kong"
          },
          {
            "x": 5138.385398,
            "y": 26.41509,
            "z": 9904608,
            "name": "HN",
            "country": "Honduras"
          },
          {
            "x": 26465.12731,
            "y": 65.56604,
            "z": 4105268,
            "name": "HR",
            "country": "Croatia"
          },
          {
            "x": 2773.081364,
            "y": 13.67924,
            "z": 11402533,
            "name": "HT",
            "country": "Haiti"
          },
          {
            "x": 31007.76841,
            "y": 75,
            "z": 9660350,
            "name": "HU",
            "country": "Hungary"
          },
          {
            "x": 11444.96068,
            "y": 28.30189,
            "z": 273523621,
            "name": "ID",
            "country": "Indonesia"
          },
          {
            "x": 6118.35733,
            "y": 16.98113,
            "z": 1380004385,
            "name": "IN",
            "country": "India"
          },
          {
            "x": 89688.95696,
            "y": 83.01887,
            "z": 4937796,
            "name": "IE",
            "country": "Ireland"
          },
          {
            "x": 12433.29698,
            "y": 7.54717,
            "z": 83992953,
            "name": "IR",
            "country": "Iran"
          },
          {
            "x": 9255.256903,
            "y": 1.415094,
            "z": 40222503,
            "name": "IQ",
            "country": "Iraq"
          },
          {
            "x": 52279.72885,
            "y": 96.69811,
            "z": 341250,
            "name": "IS",
            "country": "Iceland"
          },
          {
            "x": 38341.30757,
            "y": 18.39623,
            "z": 8655541,
            "name": "IL",
            "country": "Israel"
          },
          {
            "x": 38992.14838,
            "y": 59.90566,
            "z": 60461828,
            "name": "IT",
            "country": "Italy"
          },
          {
            "x": 8741.550443,
            "y": 55.66038,
            "z": 2961161,
            "name": "JM",
            "country": "Jamaica"
          },
          {
            "x": 9816.55453,
            "y": 35.84906,
            "z": 10203140,
            "name": "JO",
            "country": "Jordan"
          },
          {
            "x": 0,
            "y": 87.26415,
            "z": 126476458,
            "name": "JP",
            "country": "Japan"
          },
          {
            "x": 25337.1524,
            "y": 39.15094,
            "z": 18776707,
            "name": "KZ",
            "country": "Kazakhstan"
          },
          {
            "x": 4220.440248,
            "y": 14.15094,
            "z": 53771300,
            "name": "KE",
            "country": "Kenya"
          },
          {
            "x": 4706.570238,
            "y": 31.60377,
            "z": 6524191,
            "name": "KG",
            "country": "Kyrgyz Republic"
          },
          {
            "x": 4191.850003,
            "y": 41.03773,
            "z": 16718971,
            "name": "KH",
            "country": "Cambodia"
          },
          {
            "x": 2291.907219,
            "y": 88.67924,
            "z": 119446,
            "name": "KI",
            "country": "Kiribati"
          },
          {
            "x": 23259.36231,
            "y": 80.18868,
            "z": 53192,
            "name": "KN",
            "country": "St. Kitts and Nevis"
          },
          {
            "x": 42251.44506,
            "y": 62.73585,
            "z": 51269183,
            "name": "KR",
            "country": "South Korea"
          },
          {
            "x": 0,
            "y": 54.71698,
            "z": 4270563,
            "name": "KW",
            "country": "Kuwait"
          },
          {
            "x": 7805.798556,
            "y": 69.33962,
            "z": 7275556,
            "name": "LA",
            "country": "Laos"
          },
          {
            "x": 11649.05011,
            "y": 8.018867,
            "z": 6825442,
            "name": "LB",
            "country": "Lebanon"
          },
          {
            "x": 1353.84292,
            "y": 33.96227,
            "z": 5057677,
            "name": "LR",
            "country": "Liberia"
          },
          {
            "x": 10282.29108,
            "y": 2.35849,
            "z": 6871287,
            "name": "LY",
            "country": "Libya"
          },
          {
            "x": 12270.01329,
            "y": 75.9434,
            "z": 183629,
            "name": "LC",
            "country": "St. Lucia"
          },
          {
            "x": 12536.94176,
            "y": 45.28302,
            "z": 21413250,
            "name": "LK",
            "country": "Sri Lanka"
          },
          {
            "x": 2279.895874,
            "y": 34.90566,
            "z": 2142252,
            "name": "LS",
            "country": "Lesotho"
          },
          {
            "x": 36732.03474,
            "y": 75.47169,
            "z": 2722291,
            "name": "LT",
            "country": "Lithuania"
          },
          {
            "x": 110261.1574,
            "y": 93.86793,
            "z": 625976,
            "name": "LU",
            "country": "Luxembourg"
          },
          {
            "x": 29932.49391,
            "y": 60.37736,
            "z": 1886202,
            "name": "LV",
            "country": "Latvia"
          },
          {
            "x": 54797.92984,
            "y": 91.50944,
            "z": 649342,
            "name": "MO",
            "country": "Macau"
          },
          {
            "x": 6916.346412,
            "y": 35.37736,
            "z": 36910558,
            "name": "MA",
            "country": "Morocco"
          },
          {
            "x": 12324.73628,
            "y": 32.54717,
            "z": 4033963,
            "name": "MD",
            "country": "Moldova"
          },
          {
            "x": 1510.141726,
            "y": 29.24528,
            "z": 27691019,
            "name": "MG",
            "country": "Madagascar"
          },
          {
            "x": 13049.04666,
            "y": 58.49057,
            "z": 540542,
            "name": "MV",
            "country": "Maldives"
          },
          {
            "x": 17887.75074,
            "y": 17.92453,
            "z": 128932753,
            "name": "MX",
            "country": "Mexico"
          },
          {
            "x": 0,
            "y": 64.15094,
            "z": 59194,
            "name": "MH",
            "country": "Marshall Islands"
          },
          {
            "x": 15848.41929,
            "y": 0,
            "z": 2083380,
            "name": "MK",
            "country": "Macedonia"
          },
          {
            "x": 2216.773262,
            "y": 3.773585,
            "z": 20250834,
            "name": "ML",
            "country": "Mali"
          },
          {
            "x": 39222.14335,
            "y": 82.54717,
            "z": 441539,
            "name": "MT",
            "country": "Malta"
          },
          {
            "x": 4544.021569,
            "y": 9.905661,
            "z": 54409794,
            "name": "MM",
            "country": "Myanmar"
          },
          {
            "x": 18278.73079,
            "y": 47.16981,
            "z": 628062,
            "name": "ME",
            "country": "Montenegro"
          },
          {
            "x": 11470.67383,
            "y": 72.64151,
            "z": 3278292,
            "name": "MN",
            "country": "Mongolia"
          },
          {
            "x": 1229.080019,
            "y": 12.73585,
            "z": 31255435,
            "name": "MZ",
            "country": "Mozambique"
          },
          {
            "x": 4983.220633,
            "y": 19.81132,
            "z": 4649660,
            "name": "MR",
            "country": "Mauritania"
          },
          {
            "x": 19469.52459,
            "y": 78.30189,
            "z": 1271767,
            "name": "MU",
            "country": "Mauritius"
          },
          {
            "x": 1486.778248,
            "y": 40.09434,
            "z": 19129955,
            "name": "MW",
            "country": "Malawi"
          },
          {
            "x": 26435.17157,
            "y": 50.9434,
            "z": 32365998,
            "name": "MY",
            "country": "Malaysia"
          },
          {
            "x": 8893.813157,
            "y": 67.92453,
            "z": 2540916,
            "name": "NA",
            "country": "Namibia"
          },
          {
            "x": 1196.87756,
            "y": 6.132075,
            "z": 24206636,
            "name": "NE",
            "country": "Niger"
          },
          {
            "x": 4916.721381,
            "y": 4.716981,
            "z": 206139587,
            "name": "NG",
            "country": "Nigeria"
          },
          {
            "x": 5280.140581,
            "y": 23.11321,
            "z": 6624554,
            "name": "NI",
            "country": "Nicaragua"
          },
          {
            "x": 54209.56384,
            "y": 74.0566,
            "z": 17134873,
            "name": "NL",
            "country": "Netherlands"
          },
          {
            "x": 63585.90351,
            "y": 94.33962,
            "z": 5421242,
            "name": "NO",
            "country": "Norway"
          },
          {
            "x": 3800.065703,
            "y": 41.50943,
            "z": 29136808,
            "name": "NP",
            "country": "Nepal"
          },
          {
            "x": 0,
            "y": 80.66038,
            "z": 10834,
            "name": "NR",
            "country": "Nauru"
          },
          {
            "x": 42404.39374,
            "y": 97.64151,
            "z": 4822233,
            "name": "NZ",
            "country": "New Zealand"
          },
          {
            "x": 0,
            "y": 57.54717,
            "z": 5106622,
            "name": "OM",
            "country": "Oman"
          },
          {
            "x": 4622.770769,
            "y": 5.188679,
            "z": 220892331,
            "name": "PK",
            "country": "Pakistan"
          },
          {
            "x": 25381.84845,
            "y": 54.24528,
            "z": 4314768,
            "name": "PA",
            "country": "Panama"
          },
          {
            "x": 11260.84575,
            "y": 38.67924,
            "z": 32971845,
            "name": "PE",
            "country": "Peru"
          },
          {
            "x": 7953.581644,
            "y": 18.86792,
            "z": 109581085,
            "name": "PH",
            "country": "Philippines"
          },
          {
            "x": 0,
            "y": 77.83018,
            "z": 18092,
            "name": "PW",
            "country": "Palau"
          },
          {
            "x": 4101.218882,
            "y": 20.28302,
            "z": 8947027,
            "name": "PG",
            "country": "Papua New Guinea"
          },
          {
            "x": 32238.15726,
            "y": 63.20755,
            "z": 37846605,
            "name": "PL",
            "country": "Poland"
          },
          {
            "x": 33442.83157,
            "y": 59.43396,
            "z": 2860840,
            "name": "PR",
            "country": "Puerto Rico"
          },
          {
            "x": 32181.15454,
            "y": 85.84906,
            "z": 10196707,
            "name": "PT",
            "country": "Portugal"
          },
          {
            "x": 12335.47236,
            "y": 47.64151,
            "z": 7132530,
            "name": "PY",
            "country": "Paraguay"
          },
          {
            "x": 5394.071688,
            "y": 4.245283,
            "z": 5101416,
            "name": "PS",
            "country": "Palestine"
          },
          {
            "x": 85266.21059,
            "y": 68.39622,
            "z": 2881060,
            "name": "QA",
            "country": "Qatar"
          },
          {
            "x": 28832.62315,
            "y": 63.67924,
            "z": 19237682,
            "name": "RO",
            "country": "Romania"
          },
          {
            "x": 26456.38794,
            "y": 20.75472,
            "z": 145934460,
            "name": "RU",
            "country": "Russia"
          },
          {
            "x": 2098.710362,
            "y": 48.11321,
            "z": 12952209,
            "name": "RW",
            "country": "Rwanda"
          },
          {
            "x": 44328.18391,
            "y": 22.64151,
            "z": 34813867,
            "name": "SA",
            "country": "Saudi Arabia"
          },
          {
            "x": 4022.865967,
            "y": 5.660378,
            "z": 43849269,
            "name": "SD",
            "country": "Sudan"
          },
          {
            "x": 3300.085493,
            "y": 46.69811,
            "z": 16743930,
            "name": "SN",
            "country": "Senegal"
          },
          {
            "x": 93397.0488,
            "y": 97.16982,
            "z": 5850343,
            "name": "SG",
            "country": "Singapore"
          },
          {
            "x": 2482.87192,
            "y": 66.98113,
            "z": 686878,
            "name": "SB",
            "country": "Solomon Islands"
          },
          {
            "x": 1648.05336,
            "y": 39.62264,
            "z": 7976985,
            "name": "SL",
            "country": "Sierra Leone"
          },
          {
            "x": 8056.543086,
            "y": 45.75472,
            "z": 6486201,
            "name": "SV",
            "country": "El Salvador"
          },
          {
            "x": 0,
            "y": 76.8868,
            "z": 33938,
            "name": "SM",
            "country": "San Marino"
          },
          {
            "x": 829.6114289,
            "y": 1.886792,
            "z": 15893219,
            "name": "SO",
            "country": "Somalia"
          },
          {
            "x": 18210.00462,
            "y": 43.86792,
            "z": 8737370,
            "name": "RS",
            "country": "Serbia"
          },
          {
            "x": 4051.604844,
            "y": 61.79245,
            "z": 219161,
            "name": "ST",
            "country": "Sao Tome and Principe"
          },
          {
            "x": 16130.17081,
            "y": 58.96227,
            "z": 586634,
            "name": "SR",
            "country": "Suriname"
          },
          {
            "x": 30330.04289,
            "y": 67.45283,
            "z": 5459643,
            "name": "SK",
            "country": "Slovakia"
          },
          {
            "x": 36547.73896,
            "y": 69.81132,
            "z": 2078931,
            "name": "SI",
            "country": "Slovenia"
          },
          {
            "x": 50683.32351,
            "y": 85.37736,
            "z": 10099270,
            "name": "SE",
            "country": "Sweden"
          },
          {
            "x": 8392.717564,
            "y": 0,
            "z": 1160164,
            "name": "SZ",
            "country": "Eswatini"
          },
          {
            "x": 24361.89394,
            "y": 70.75471,
            "z": 98340,
            "name": "SC",
            "country": "Seychelles"
          },
          {
            "x": 1519.912362,
            "y": 10.84906,
            "z": 16425859,
            "name": "TD",
            "country": "Chad"
          },
          {
            "x": 2107.877261,
            "y": 15.56604,
            "z": 8278736,
            "name": "TG",
            "country": "Togo"
          },
          {
            "x": 17286.86661,
            "y": 24.5283,
            "z": 69799978,
            "name": "TH",
            "country": "Thailand"
          },
          {
            "x": 3657.573507,
            "y": 27.35849,
            "z": 9537642,
            "name": "TJ",
            "country": "Tajikistan"
          },
          {
            "x": 0,
            "y": 38.20755,
            "z": 6031187,
            "name": "TM",
            "country": "Turkmenistan"
          },
          {
            "x": 3181.137188,
            "y": 52.83019,
            "z": 1318442,
            "name": "TL",
            "country": "Timor-Leste"
          },
          {
            "x": 0,
            "y": 84.43396,
            "z": 105697,
            "name": "TO",
            "country": "Tonga"
          },
          {
            "x": 23728.15865,
            "y": 53.30189,
            "z": 1399491,
            "name": "TT",
            "country": "Trinidad and Tobago"
          },
          {
            "x": 9727.504259,
            "y": 24.0566,
            "z": 11818618,
            "name": "TN",
            "country": "Tunisia"
          },
          {
            "x": 28384.98778,
            "y": 11.79245,
            "z": 84339067,
            "name": "TR",
            "country": "Turkey"
          },
          {
            "x": 4411.003116,
            "y": 92.92453,
            "z": 11792,
            "name": "TV",
            "country": "Tuvalu"
          },
          {
            "x": 2635.335891,
            "y": 33.01887,
            "z": 59734213,
            "name": "TZ",
            "country": "Tanzania"
          },
          {
            "x": 2177.595854,
            "y": 19.33962,
            "z": 45741000,
            "name": "UG",
            "country": "Uganda"
          },
          {
            "x": 12377.01729,
            "y": 12.26415,
            "z": 43733759,
            "name": "UA",
            "country": "Ukraine"
          },
          {
            "x": 21608.43027,
            "y": 87.73585,
            "z": 3473727,
            "name": "UY",
            "country": "Uruguay"
          },
          {
            "x": 60235.72849,
            "y": 46.22641,
            "z": 331002647,
            "name": "US",
            "country": "United States"
          },
          {
            "x": 6994.169412,
            "y": 30.18868,
            "z": 33469199,
            "name": "UZ",
            "country": "Uzbekistan"
          },
          {
            "x": 12105.38136,
            "y": 86.79245,
            "z": 110947,
            "name": "VC",
            "country": "St. Vincent and the Grenadines"
          },
          {
            "x": 8200.331867,
            "y": 44.81132,
            "z": 97338583,
            "name": "VN",
            "country": "Vietnam"
          },
          {
            "x": 2762.791388,
            "y": 78.77358,
            "z": 307150,
            "name": "VU",
            "country": "Vanuatu"
          },
          {
            "x": 6295.731841,
            "y": 91.98113,
            "z": 198410,
            "name": "WS",
            "country": "Samoa"
          },
          {
            "x": 11466.18967,
            "y": 40.56604,
            "z": 59308690,
            "name": "ZA",
            "country": "South Africa"
          },
          {
            "x": 3270.035112,
            "y": 42.92453,
            "z": 18383956,
            "name": "ZM",
            "country": "Zambia"
          },
          {
            "x": 2744.690758,
            "y": 13.20755,
            "z": 14862927,
            "name": "ZW",
            "country": "Zimbabwe"
          }
         ]
    }]

});
