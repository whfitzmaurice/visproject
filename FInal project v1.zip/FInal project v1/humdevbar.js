Highcharts.chart('container', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Average Human Development 2020 - 2021'
    },
    subtitle: {
        text: 'Source: <a href="https://hdr.undp.org/en/content/human-development-index-hdi">Human Development Index: UNDP</a>'
    },
    xAxis: {
        type: 'category',
        labels: {
            rotation: -45,
            style: {
                fontSize: '13px',
                fontFamily: 'Verdana, sans-serif'
            }
        }
    },
    yAxis: {
        min: 0,
        max: 100,
        title: {
            text: 'Human Development %'
        }
    },
    legend: {
        enabled: false
    },
    tooltip: {
        pointFormat: 'Human Development: <b>{point.y:.1f} %</b>'
    },
    series: [{
        name: 'Population',
        color: '#666666',
        data: [
            [1990,45.68783069  ],
            [2000,58.25555556  ],
            [2010,68.35608466  ],
            [2014,70.3037037  ],
            [2015,70.67513228  ],
            [2017,71.67830688  ],
            [2018,71.94232804  ],
            [2019,72.24232804  ]
          ],
        dataLabels: {
            enabled: true,
            rotation: -90,
            color: '#FFFFFF',
            align: 'right',
            format: '{point.y:.1f}', // one decimal
            y: 10, // 10 pixels down from the top
            style: {
                fontSize: '13px',
                fontFamily: 'Verdana, sans-serif'
            }
        }
    }]
});