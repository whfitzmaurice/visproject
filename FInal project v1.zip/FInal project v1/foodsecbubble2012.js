
Highcharts.chart('container', {

    chart: {
        type: 'bubble',
        plotBorderWidth: 1,
        zoomType: 'xy'
    },

    legend: {
        enabled: false
    },

    title: {
        text: 'Food Security against GDP per capita 2012'
    },

    subtitle: {
        text: 'Sources: <a href="https://ourworldindata.org/grapher/gdp-per-capita-worldbank">GDP: OWID</a> , <a href="https://impact.economist.com/sustainability/project/food-security-index/">Food Security: Economist</a> , <a href="https://ourworldindata.org/grapher/population-past-future">Population: OWID</a>'
    },

    accessibility: {
        point: {
            valueDescriptionFormat: '{index}. {point.name}, fat: {point.x}g, sugar: {point.y}g, obesity: {point.z}%.'
        }
    },

    xAxis: {
        gridLineWidth: 1,
        title: {
            text: 'GDP Per Capita'
        },
        labels: {
            format: '{value} $'
        },
        plotLines: [{
            color: '',
            dashStyle: '',
            width: 0,
            value: 0,
            label: {
                rotation: 0,
                y: 0,
                style: {
                    fontStyle: 'italic'
                },
                text: ''
            },
            zIndex: 3
        }],
        accessibility: {
            rangeDescription: 'Range: 60 to 100 grams.'
        }
    },

    yAxis: {
        startOnTick: false,
        endOnTick: false,
        title: {
            text: 'Education %'
        },
        labels: {
            format: '{value} %'
        },
        maxPadding: 0.2,
        plotLines: [{
            color: '',
            dashStyle: '',
            width: 0,
            value: 0,
            label: {
                align: 'right',
                style: {
                    fontStyle: 'italic'
                },
                text: '',
                x: 0
            },
            zIndex: 3
        }],
        accessibility: {
            rangeDescription: 'Range: 0 to 160 grams.'
        }
    },

    tooltip: {
        useHTML: true,
        headerFormat: '<table>',
        pointFormat: '<tr><th colspan="2"><h3>{point.country}</h3></th></tr>' +
            '<tr><th>Fat intake:</th><td>{point.x}g</td></tr>' +
            '<tr><th>Sugar intake:</th><td>{point.y}g</td></tr>' +
            '<tr><th>Obesity (adults):</th><td>{point.z}%</td></tr>',
        footerFormat: '</table>',
        followPointer: true
    },

    plotOptions: {
        series: {
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },

    series: [{
        color: '#FF0000',
        data:[
          {
            "x": 2065.036235,
            "y": 41.4,
            "z": 38041757,
            "name": "AF",
            "country": "Afghanistan"
          },
          {
            "x": 6670.331458,
            "y": 50,
            "z": 31825299,
            "name": "AO",
            "country": "Angola"
          },
          {
            "x": 13671.48842,
            "y": 74.6,
            "z": 2880913,
            "name": "AL",
            "country": "Albania"
          },
          {
            "x": 67119.15324,
            "y": 80.2,
            "z": 9770526,
            "name": "AE",
            "country": "United Arab Emirates"
          },
          {
            "x": 22063.90437,
            "y": 85.5,
            "z": 44780675,
            "name": "AR",
            "country": "Argentina"
          },
          {
            "x": 13653.76338,
            "y": 74,
            "z": 2957728,
            "name": "AM",
            "country": "Armenia"
          },
          {
            "x": 21548.72501,
            "y": 66.5,
            "z": 97115,
            "name": "AG",
            "country": "Antigua and Barbuda"
          },
          {
            "x": 49455.53851,
            "y": 92.4,
            "z": 25203200,
            "name": "AU",
            "country": "Australia"
          },
          {
            "x": 55833.31569,
            "y": 86.5,
            "z": 8955108,
            "name": "AT",
            "country": "Austria"
          },
          {
            "x": 14439.3014,
            "y": 71.1,
            "z": 10047719,
            "name": "AZ",
            "country": "Azerbaijan"
          },
          {
            "x": 751.6641528,
            "y": 41.7,
            "z": 11530577,
            "name": "BI",
            "country": "Burundi"
          },
          {
            "x": 51742.72638,
            "y": 90.2,
            "z": 11539326,
            "name": "BE",
            "country": "Belgium"
          },
          {
            "x": 3287.309538,
            "y": 47.8,
            "z": 11801151,
            "name": "BJ",
            "country": "Benin"
          },
          {
            "x": 2178.322879,
            "y": 31.2,
            "z": 20321383,
            "name": "BF",
            "country": "Burkina Faso"
          },
          {
            "x": 4753.726597,
            "y": 52.9,
            "z": 163046173,
            "name": "BD",
            "country": "Bangladesh"
          },
          {
            "x": 23191.57458,
            "y": 77.9,
            "z": 7000117,
            "name": "BG",
            "country": "Bulgaria"
          },
          {
            "x": 45060.42374,
            "y": 76.9,
            "z": 1641164,
            "name": "BH",
            "country": "Bahrain"
          },
          {
            "x": 37100.36296,
            "y": 74,
            "z": 389486,
            "name": "BS",
            "country": "Bahamas"
          },
          {
            "x": 14896.79004,
            "y": 71.1,
            "z": 3300998,
            "name": "BA",
            "country": "Bosnia and Herzegovina"
          },
          {
            "x": 19283.11715,
            "y": 83.8,
            "z": 9452409,
            "name": "BY",
            "country": "Belarus"
          },
          {
            "x": 7251.921351,
            "y": 69.5,
            "z": 390351,
            "name": "BZ",
            "country": "Belize"
          },
          {
            "x": 8724.474187,
            "y": 69.5,
            "z": 11513102,
            "name": "BO",
            "country": "Bolivia"
          },
          {
            "x": 14763.8717,
            "y": 69.4,
            "z": 211049519,
            "name": "BR",
            "country": "Brazil"
          },
          {
            "x": 15639.04784,
            "y": 78.2,
            "z": 287021,
            "name": "BB",
            "country": "Barbados"
          },
          {
            "x": 62098.01134,
            "y": 70.2,
            "z": 433296,
            "name": "BN",
            "country": "Brunei Darussalam"
          },
          {
            "x": 11832.15825,
            "y": 49.6,
            "z": 763094,
            "name": "BT",
            "country": "Bhutan"
          },
          {
            "x": 17776.80831,
            "y": 67.6,
            "z": 2303703,
            "name": "BW",
            "country": "Botswana"
          },
          {
            "x": 945.1420429,
            "y": 35.3,
            "z": 4745179,
            "name": "CF",
            "country": "Central African Republic"
          },
          {
            "x": 49006.74311,
            "y": 89.4,
            "z": 37411038,
            "name": "CA",
            "country": "Canada"
          },
          {
            "x": 70920.32473,
            "y": 90,
            "z": 8591361,
            "name": "CH",
            "country": "Switzerland"
          },
          {
            "x": 24967.58021,
            "y": 81,
            "z": 18952035,
            "name": "CL",
            "country": "Chile"
          },
          {
            "x": 16092.30077,
            "y": 65.7,
            "z": 1433783692,
            "name": "CN",
            "country": "China"
          },
          {
            "x": 5212.554021,
            "y": 45.3,
            "z": 25716554,
            "name": "CI",
            "country": "Cote d'Ivoire"
          },
          {
            "x": 3642.276273,
            "y": 54.7,
            "z": 25876387,
            "name": "CM",
            "country": "Cameroon"
          },
          {
            "x": 1097.94884,
            "y": 49.6,
            "z": 86790568,
            "name": "CD",
            "country": "DR Congo"
          },
          {
            "x": 3842.798856,
            "y": 54.3,
            "z": 5380504,
            "name": "CG",
            "country": "Congo Republic"
          },
          {
            "x": 14585.30249,
            "y": 68.2,
            "z": 50339443,
            "name": "CO",
            "country": "Colombia"
          },
          {
            "x": 3059.491726,
            "y": 48.2,
            "z": 850891,
            "name": "KM",
            "country": "Comoros"
          },
          {
            "x": 7171.826425,
            "y": 56.2,
            "z": 549936,
            "name": "CV",
            "country": "Cabo Verde"
          },
          {
            "x": 20805.34368,
            "y": 72.6,
            "z": 5047561,
            "name": "CR",
            "country": "Costa Rica"
          },
          {
            "x": 40226.80949,
            "y": 82.7,
            "z": 1198574,
            "name": "CY",
            "country": "Cyprus"
          },
          {
            "x": 40696.31049,
            "y": 89,
            "z": 10689213,
            "name": "CZ",
            "country": "Czech Republic"
          },
          {
            "x": 53639.26072,
            "y": 94.3,
            "z": 83517046,
            "name": "DE",
            "country": "Germany"
          },
          {
            "x": 5534.766172,
            "y": 32.5,
            "z": 973557,
            "name": "DJ",
            "country": "Djibouti"
          },
          {
            "x": 11905.87052,
            "y": 63.2,
            "z": 71808,
            "name": "DM",
            "country": "Dominica"
          },
          {
            "x": 57678.09889,
            "y": 92,
            "z": 5771877,
            "name": "DK",
            "country": "Denmark"
          },
          {
            "x": 18412.89999,
            "y": 66.6,
            "z": 10738957,
            "name": "DO",
            "country": "Dominican Republic"
          },
          {
            "x": 11510.55709,
            "y": 67.2,
            "z": 43053054,
            "name": "DZ",
            "country": "Algeria"
          },
          {
            "x": 11370.6033,
            "y": 70.2,
            "z": 17373657,
            "name": "EC",
            "country": "Ecuador"
          },
          {
            "x": 11763.25328,
            "y": 61.8,
            "z": 100388076,
            "name": "EG",
            "country": "Egypt"
          },
          {
            "x": 40805.91697,
            "y": 83.1,
            "z": 46736782,
            "name": "ES",
            "country": "Spain"
          },
          {
            "x": 36830.07479,
            "y": 88.2,
            "z": 1325649,
            "name": "EE",
            "country": "Estonia"
          },
          {
            "x": 2221.404665,
            "y": 34.1,
            "z": 112078727,
            "name": "ET",
            "country": "Ethiopia"
          },
          {
            "x": 48689.23415,
            "y": 92.7,
            "z": 5532159,
            "name": "FI",
            "country": "Finland"
          },
          {
            "x": 13684.36082,
            "y": 76.4,
            "z": 889955,
            "name": "FJ",
            "country": "Fiji"
          },
          {
            "x": 45834.16691,
            "y": 81.7,
            "z": 65129731,
            "name": "FR",
            "country": "France"
          },
          {
            "x": 3466.413293,
            "y": 58.1,
            "z": 113811,
            "name": "FM",
            "country": "Micronesia, Fed. Sts."
          },
          {
            "x": 14950.07708,
            "y": 65,
            "z": 2172578,
            "name": "GA",
            "country": "Gabon"
          },
          {
            "x": 46406.46175,
            "y": 92.8,
            "z": 67530161,
            "name": "GB",
            "country": "United Kingdom"
          },
          {
            "x": 14989.25816,
            "y": 86.2,
            "z": 3996762,
            "name": "GE",
            "country": "Georgia"
          },
          {
            "x": 5396.866088,
            "y": 56.3,
            "z": 30417858,
            "name": "GH",
            "country": "Ghana"
          },
          {
            "x": 2567.033987,
            "y": 35.4,
            "z": 12771246,
            "name": "GN",
            "country": "Guinea"
          },
          {
            "x": 2222.87959,
            "y": 40.6,
            "z": 2347696,
            "name": "GM",
            "country": "Gambia"
          },
          {
            "x": 1939.28951,
            "y": 41.4,
            "z": 1920917,
            "name": "GW",
            "country": "Guinea-Bissau"
          },
          {
            "x": 18502.56396,
            "y": 46.7,
            "z": 1355982,
            "name": "GQ",
            "country": "Equatorial Guinea"
          },
          {
            "x": 29723.22196,
            "y": 84.9,
            "z": 10473452,
            "name": "GR",
            "country": "Greece"
          },
          {
            "x": 17050.29304,
            "y": 77,
            "z": 112002,
            "name": "GD",
            "country": "Grenada"
          },
          {
            "x": 8653.308195,
            "y": 51.9,
            "z": 17581476,
            "name": "GT",
            "country": "Guatemala"
          },
          {
            "x": 13082.20262,
            "y": 60.1,
            "z": 782775,
            "name": "GY",
            "country": "Guyana"
          },
          {
            "x": 59586.20401,
            "y": 88,
            "z": 7436157,
            "name": "HK",
            "country": "Hong Kong"
          },
          {
            "x": 5736.181633,
            "y": 49.9,
            "z": 9746115,
            "name": "HN",
            "country": "Honduras"
          },
          {
            "x": 28753.51627,
            "y": 80.5,
            "z": 4130299,
            "name": "HR",
            "country": "Croatia"
          },
          {
            "x": 2905.438565,
            "y": 45.6,
            "z": 11263079,
            "name": "HT",
            "country": "Haiti"
          },
          {
            "x": 32553.5237,
            "y": 82.1,
            "z": 9684680,
            "name": "HU",
            "country": "Hungary"
          },
          {
            "x": 11811.97556,
            "y": 65,
            "z": 270625567,
            "name": "ID",
            "country": "Indonesia"
          },
          {
            "x": 6713.932211,
            "y": 55.5,
            "z": 1366417756,
            "name": "IN",
            "country": "India"
          },
          {
            "x": 87786.15693,
            "y": 92.2,
            "z": 4882498,
            "name": "IE",
            "country": "Ireland"
          },
          {
            "x": 12389.22335,
            "y": 75.6,
            "z": 82913893,
            "name": "IR",
            "country": "Iran"
          },
          {
            "x": 10565.24743,
            "y": 55.7,
            "z": 39309789,
            "name": "IQ",
            "country": "Iraq"
          },
          {
            "x": 56913.95685,
            "y": 92.6,
            "z": 339037,
            "name": "IS",
            "country": "Iceland"
          },
          {
            "x": 40007.31916,
            "y": 88.3,
            "z": 8519373,
            "name": "IL",
            "country": "Israel"
          },
          {
            "x": 42662.52237,
            "y": 79.3,
            "z": 60550092,
            "name": "IT",
            "country": "Italy"
          },
          {
            "x": 9777.005686,
            "y": 68.9,
            "z": 2948277,
            "name": "JM",
            "country": "Jamaica"
          },
          {
            "x": 10071.37989,
            "y": 66.7,
            "z": 10101697,
            "name": "JO",
            "country": "Jordan"
          },
          {
            "x": 41380.09358,
            "y": 85.1,
            "z": 126860299,
            "name": "JP",
            "country": "Japan"
          },
          {
            "x": 26351.80444,
            "y": 83,
            "z": 18551428,
            "name": "KZ",
            "country": "Kazakhstan"
          },
          {
            "x": 4329.871884,
            "y": 53.4,
            "z": 52573967,
            "name": "KE",
            "country": "Kenya"
          },
          {
            "x": 5258.366696,
            "y": 73,
            "z": 6415851,
            "name": "KG",
            "country": "Kyrgyz Republic"
          },
          {
            "x": 4388.800909,
            "y": 48.4,
            "z": 16486542,
            "name": "KH",
            "country": "Cambodia"
          },
          {
            "x": 2270.108607,
            "y": 59.4,
            "z": 117608,
            "name": "KI",
            "country": "Kiribati"
          },
          {
            "x": 26235.55455,
            "y": 67.3,
            "z": 52834,
            "name": "KN",
            "country": "St. Kitts and Nevis"
          },
          {
            "x": 42719.00026,
            "y": 86.5,
            "z": 51225321,
            "name": "KR",
            "country": "South Korea"
          },
          {
            "x": 49853.73628,
            "y": 63.8,
            "z": 4207077,
            "name": "KW",
            "country": "Kuwait"
          },
          {
            "x": 7886.652814,
            "y": 48.1,
            "z": 7169456,
            "name": "LA",
            "country": "Laos"
          },
          {
            "x": 14551.59371,
            "y": 60.4,
            "z": 6855709,
            "name": "LB",
            "country": "Lebanon"
          },
          {
            "x": 1427.81909,
            "y": 42.6,
            "z": 4937374,
            "name": "LR",
            "country": "Liberia"
          },
          {
            "x": 15174.16252,
            "y": 61,
            "z": 6777453,
            "name": "LY",
            "country": "Libya"
          },
          {
            "x": 15448.34491,
            "y": 67.2,
            "z": 182795,
            "name": "LC",
            "country": "St. Lucia"
          },
          {
            "x": 13070.12564,
            "y": 74.6,
            "z": 21323734,
            "name": "LK",
            "country": "Sri Lanka"
          },
          {
            "x": 2583.924371,
            "y": 53.2,
            "z": 2125267,
            "name": "LS",
            "country": "Lesotho"
          },
          {
            "x": 37062.58675,
            "y": 89.8,
            "z": 2759631,
            "name": "LT",
            "country": "Lithuania"
          },
          {
            "x": 113940.2374,
            "y": 80.6,
            "z": 615730,
            "name": "LU",
            "country": "Luxembourg"
          },
          {
            "x": 30858.75007,
            "y": 88.3,
            "z": 1906740,
            "name": "LV",
            "country": "Latvia"
          },
          {
            "x": 7537.485272,
            "y": 56.9,
            "z": 36471766,
            "name": "MA",
            "country": "Morocco"
          },
          {
            "x": 13022.00461,
            "y": 71.1,
            "z": 4043258,
            "name": "MD",
            "country": "Moldova"
          },
          {
            "x": 1618.532314,
            "y": 48.6,
            "z": 26969306,
            "name": "MG",
            "country": "Madagascar"
          },
          {
            "x": 19531.04256,
            "y": 57.3,
            "z": 530957,
            "name": "MV",
            "country": "Maldives"
          },
          {
            "x": 19701.33767,
            "y": 70.3,
            "z": 127575529,
            "name": "MX",
            "country": "Mexico"
          },
          {
            "x": 4029.086329,
            "y": 70.7,
            "z": 58791,
            "name": "MH",
            "country": "Marshall Islands"
          },
          {
            "x": 16600.14365,
            "y": 70.4,
            "z": 2083458,
            "name": "MK",
            "country": "Macedonia"
          },
          {
            "x": 2321.917173,
            "y": 28.6,
            "z": 19658023,
            "name": "ML",
            "country": "Mali"
          },
          {
            "x": 43950.58805,
            "y": 82.5,
            "z": 440377,
            "name": "MT",
            "country": "Malta"
          },
          {
            "x": 5082.503161,
            "y": 46.4,
            "z": 54045422,
            "name": "MM",
            "country": "Myanmar"
          },
          {
            "x": 21533.94924,
            "y": 80.3,
            "z": 627988,
            "name": "ME",
            "country": "Montenegro"
          },
          {
            "x": 12316.79137,
            "y": 73.6,
            "z": 3225166,
            "name": "MN",
            "country": "Mongolia"
          },
          {
            "x": 1281.506041,
            "y": 39.5,
            "z": 30366043,
            "name": "MZ",
            "country": "Mozambique"
          },
          {
            "x": 5197.072251,
            "y": 39.6,
            "z": 4525698,
            "name": "MR",
            "country": "Mauritania"
          },
          {
            "x": 22870.28625,
            "y": 73.6,
            "z": 1269670,
            "name": "MU",
            "country": "Mauritius"
          },
          {
            "x": 1514.662677,
            "y": 47,
            "z": 18628749,
            "name": "MW",
            "country": "Malawi"
          },
          {
            "x": 28364.47632,
            "y": 72.6,
            "z": 31949789,
            "name": "MY",
            "country": "Malaysia"
          },
          {
            "x": 9845.213068,
            "y": 58.4,
            "z": 2494524,
            "name": "NA",
            "country": "Namibia"
          },
          {
            "x": 1224.510262,
            "y": 24.9,
            "z": 23310719,
            "name": "NE",
            "country": "Niger"
          },
          {
            "x": 5135.499469,
            "y": 49.9,
            "z": 200963603,
            "name": "NG",
            "country": "Nigeria"
          },
          {
            "x": 5451.707835,
            "y": 57.3,
            "z": 6545503,
            "name": "NI",
            "country": "Nicaragua"
          },
          {
            "x": 56629.11079,
            "y": 91.4,
            "z": 17097123,
            "name": "NL",
            "country": "Netherlands"
          },
          {
            "x": 64452.81262,
            "y": 93,
            "z": 5378859,
            "name": "NO",
            "country": "Norway"
          },
          {
            "x": 3952.760349,
            "y": 52.1,
            "z": 28608715,
            "name": "NP",
            "country": "Nepal"
          },
          {
            "x": 42877.94291,
            "y": 92.6,
            "z": 4783062,
            "name": "NZ",
            "country": "New Zealand"
          },
          {
            "x": 27294.57298,
            "y": 71.8,
            "z": 4974992,
            "name": "OM",
            "country": "Oman"
          },
          {
            "x": 4690.484777,
            "y": 40.2,
            "z": 216565317,
            "name": "PK",
            "country": "Pakistan"
          },
          {
            "x": 31432.11327,
            "y": 70,
            "z": 4246440,
            "name": "PA",
            "country": "Panama"
          },
          {
            "x": 12853.69207,
            "y": 74,
            "z": 32510462,
            "name": "PE",
            "country": "Peru"
          },
          {
            "x": 8914.723798,
            "y": 67.8,
            "z": 108116622,
            "name": "PH",
            "country": "Philippines"
          },
          {
            "x": 17572.6226,
            "y": 85.5,
            "z": 18001,
            "name": "PW",
            "country": "Palau"
          },
          {
            "x": 4349.808048,
            "y": 43.9,
            "z": 8776119,
            "name": "PG",
            "country": "Papua New Guinea"
          },
          {
            "x": 33120.51784,
            "y": 86.9,
            "z": 37887771,
            "name": "PL",
            "country": "Poland"
          },
          {
            "x": 34879.70597,
            "y": 76.8,
            "z": 10226178,
            "name": "PT",
            "country": "Portugal"
          },
          {
            "x": 12615.52865,
            "y": 63.8,
            "z": 7044639,
            "name": "PY",
            "country": "Paraguay"
          },
          {
            "x": 6245.448697,
            "y": 67.8,
            "z": 4981422,
            "name": "PS",
            "country": "Palestine"
          },
          {
            "x": 90043.799,
            "y": 65.9,
            "z": 2832071,
            "name": "QA",
            "country": "Qatar"
          },
          {
            "x": 29857.64647,
            "y": 76.5,
            "z": 19364558,
            "name": "RO",
            "country": "Romania"
          },
          {
            "x": 27210.546,
            "y": 82.3,
            "z": 145872260,
            "name": "RU",
            "country": "Russia"
          },
          {
            "x": 2227.517033,
            "y": 45.8,
            "z": 12626938,
            "name": "RW",
            "country": "Rwanda"
          },
          {
            "x": 46962.14769,
            "y": 78.9,
            "z": 34268529,
            "name": "SA",
            "country": "Saudi Arabia"
          },
          {
            "x": 4185.600635,
            "y": 34.5,
            "z": 42813237,
            "name": "SD",
            "country": "Sudan"
          },
          {
            "x": 3361.461548,
            "y": 34.5,
            "z": 16296362,
            "name": "SN",
            "country": "Senegal"
          },
          {
            "x": 98411.58206,
            "y": 84.4,
            "z": 5804343,
            "name": "SG",
            "country": "Singapore"
          },
          {
            "x": 2660.979697,
            "y": 47.4,
            "z": 669821,
            "name": "SB",
            "country": "Solomon Islands"
          },
          {
            "x": 1719.789744,
            "y": 40.6,
            "z": 7813207,
            "name": "SL",
            "country": "Sierra Leone"
          },
          {
            "x": 8796.062064,
            "y": 55.5,
            "z": 6453550,
            "name": "SV",
            "country": "El Salvador"
          },
          {
            "x": 18292.17503,
            "y": 78.3,
            "z": 8772228,
            "name": "RS",
            "country": "Serbia"
          },
          {
            "x": 4005.341623,
            "y": 56.7,
            "z": 215048,
            "name": "ST",
            "country": "Sao Tome and Principe"
          },
          {
            "x": 19036.74504,
            "y": 67.5,
            "z": 581363,
            "name": "SR",
            "country": "Suriname"
          },
          {
            "x": 31871.33492,
            "y": 82.6,
            "z": 5457012,
            "name": "SK",
            "country": "Slovakia"
          },
          {
            "x": 38905.54786,
            "y": 91,
            "z": 2078654,
            "name": "SI",
            "country": "Slovenia"
          },
          {
            "x": 52531.17438,
            "y": 91.8,
            "z": 10036391,
            "name": "SE",
            "country": "Sweden"
          },
          {
            "x": 8621.804067,
            "y": 55.7,
            "z": 1148133,
            "name": "SZ",
            "country": "Eswatini"
          },
          {
            "x": 27521.16677,
            "y": 72.6,
            "z": 97741,
            "name": "SC",
            "country": "Seychelles"
          },
          {
            "x": 1579.626101,
            "y": 28.8,
            "z": 15946882,
            "name": "TD",
            "country": "Chad"
          },
          {
            "x": 2121.899918,
            "y": 51.7,
            "z": 8082359,
            "name": "TG",
            "country": "Togo"
          },
          {
            "x": 18453.46982,
            "y": 68.2,
            "z": 69625581,
            "name": "TH",
            "country": "Thailand"
          },
          {
            "x": 3581.411402,
            "y": 68.2,
            "z": 9321023,
            "name": "TJ",
            "country": "Tajikistan"
          },
          {
            "x": 15538.41997,
            "y": 65.3,
            "z": 5942094,
            "name": "TM",
            "country": "Turkmenistan"
          },
          {
            "x": 3552.596998,
            "y": 51,
            "z": 1293120,
            "name": "TL",
            "country": "Timor-Leste"
          },
          {
            "x": 6378.128346,
            "y": 77.5,
            "z": 104497,
            "name": "TO",
            "country": "Tonga"
          },
          {
            "x": 25827.88507,
            "y": 72.8,
            "z": 1394969,
            "name": "TT",
            "country": "Trinidad and Tobago"
          },
          {
            "x": 10755.57266,
            "y": 66.1,
            "z": 11694721,
            "name": "TN",
            "country": "Tunisia"
          },
          {
            "x": 28199.05159,
            "y": 73.1,
            "z": 83429607,
            "name": "TR",
            "country": "Turkey"
          },
          {
            "x": 2660.420433,
            "y": 42.9,
            "z": 58005461,
            "name": "TZ",
            "country": "Tanzania"
          },
          {
            "x": 2187.465227,
            "y": 52.3,
            "z": 44269587,
            "name": "UG",
            "country": "Uganda"
          },
          {
            "x": 12808.799,
            "y": 79.9,
            "z": 43993643,
            "name": "UA",
            "country": "Ukraine"
          },
          {
            "x": 23032.73404,
            "y": 76.5,
            "z": 3461731,
            "name": "UY",
            "country": "Uruguay"
          },
          {
            "x": 62630.87328,
            "y": 90,
            "z": 329064917,
            "name": "US",
            "country": "United States"
          },
          {
            "x": 7014.324699,
            "y": 72.9,
            "z": 32981714,
            "name": "UZ",
            "country": "Uzbekistan"
          },
          {
            "x": 12484.72871,
            "y": 68.4,
            "z": 110593,
            "name": "VC",
            "country": "St. Vincent and the Grenadines"
          },
          {
            "x": 8041.178384,
            "y": 63,
            "z": 96462108,
            "name": "VN",
            "country": "Vietnam"
          },
          {
            "x": 3117.678832,
            "y": 56.1,
            "z": 299882,
            "name": "VU",
            "country": "Vanuatu"
          },
          {
            "x": 6516.520678,
            "y": 71.3,
            "z": 197093,
            "name": "WS",
            "country": "Samoa"
          },
          {
            "x": 12481.81351,
            "y": 72.4,
            "z": 58558267,
            "name": "ZA",
            "country": "South Africa"
          },
          {
            "x": 3470.448024,
            "y": 55.7,
            "z": 17861034,
            "name": "ZM",
            "country": "Zambia"
          },
          {
            "x": 3027.656038,
            "y": 58.7,
            "z": 14645473,
            "name": "ZW",
            "country": "Zimbabwe"
          }
         ]
    }]

});
