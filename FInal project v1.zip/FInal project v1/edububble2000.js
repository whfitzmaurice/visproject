
Highcharts.chart('container', {

    chart: {
        type: 'bubble',
        plotBorderWidth: 1,
        zoomType: 'xy'
    },

    legend: {
        enabled: false
    },

    title: {
        text: 'Education against GDP per capita 2000'
    },

    subtitle: {
        text: 'Sources: <a href="https://ourworldindata.org/grapher/gdp-per-capita-worldbank">GDP: OWID</a> , <a href="https://hdr.undp.org/en/indicators/103706">Education: UNDP</a> , <a href="https://ourworldindata.org/grapher/population-past-future">Population: OWID</a>'
    },

    accessibility: {
        point: {
            valueDescriptionFormat: '{index}. {point.name}, $: {point.x}%, sugar: {point.y}%, obesity: {point.z}.'
        }
    },

    xAxis: {
        gridLineWidth: 1,
        title: {
            text: 'GDP Per Capita'
        },
        labels: {
            format: '{value} $'
        },
        plotLines: [{
            color: '',
            dashStyle: '',
            width: 0,
            value: 0,
            label: {
                rotation: 0,
                y: 0,
                style: {
                    fontStyle: 'italic'
                },
                text: ''
            },
            zIndex: 3
        }],
        accessibility: {
            rangeDescription: 'Range: 60 to 100 grams.'
        }
    },

    yAxis: {
        startOnTick: false,
        endOnTick: false,
        title: {
            text: 'Education %'
        },
        labels: {
            format: '{value} %'
        },
        maxPadding: 0.2,
        plotLines: [{
            color: '',
            dashStyle: '',
            width: 0,
            value: 0,
            label: {
                align: '',
                style: {
                    fontStyle: ''
                },
                text: '',
                x: 0
            },
            zIndex: 3
        }],
        accessibility: {
            rangeDescription: 'Range: 0 to 160 grams.'
        }
    },

    tooltip: {
        useHTML: true,
        headerFormat: '<table>',
        pointFormat: '<tr><th colspan="2"><h3>{point.country}</h3></th></tr>' +
            '<tr><th>GDP Per Capita:</th><td>{point.x}$</td></tr>' +
            '<tr><th>Education:</th><td>{point.y}%</td></tr>' +
            '<tr><th>Population:</th><td>{point.z}</td></tr>',
        footerFormat: '</table>',
        followPointer: true
    },

    plotOptions: {
        series: {
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },

    series: [{
        data:[
          {
            "x": 0,
            "y": 23.5,
            "z": 20779957,
            "name": "AF",
            "country": "Afghanistan"
          },
          {
            "x": 4727.966314,
            "y": 28.8,
            "z": 16395476,
            "name": "AO",
            "country": "Angola"
          },
          {
            "x": 5893.136233,
            "y": 58.6,
            "z": 3129246,
            "name": "AL",
            "country": "Albania"
          },
          {
            "x": 102494.7146,
            "y": 57.3,
            "z": 3134067,
            "name": "AE",
            "country": "United Arab Emirates"
          },
          {
            "x": 18625.28355,
            "y": 73.6,
            "z": 36870796,
            "name": "AR",
            "country": "Argentina"
          },
          {
            "x": 4048.249904,
            "y": 67.1,
            "z": 3069597,
            "name": "AM",
            "country": "Armenia"
          },
          {
            "x": 18313.34971,
            "y": 0,
            "z": 76007,
            "name": "AG",
            "country": "Antigua and Barbuda"
          },
          {
            "x": 38343.00215,
            "y": 89.5,
            "z": 18991434,
            "name": "AU",
            "country": "Australia"
          },
          {
            "x": 46403.2777,
            "y": 73.1,
            "z": 8069276,
            "name": "AT",
            "country": "Austria"
          },
          {
            "x": 4063.471641,
            "y": 64,
            "z": 8122743,
            "name": "AZ",
            "country": "Azerbaijan"
          },
          {
            "x": 828.00046,
            "y": 18.7,
            "z": 6378871,
            "name": "BI",
            "country": "Burundi"
          },
          {
            "x": 43023.30716,
            "y": 83.3,
            "z": 10282046,
            "name": "BE",
            "country": "Belgium"
          },
          {
            "x": 2478.218238,
            "y": 27.3,
            "z": 6865946,
            "name": "BJ",
            "country": "Benin"
          },
          {
            "x": 1296.74796,
            "y": 13.9,
            "z": 11607951,
            "name": "BF",
            "country": "Burkina Faso"
          },
          {
            "x": 1937.729192,
            "y": 34.4,
            "z": 127657862,
            "name": "BD",
            "country": "Bangladesh"
          },
          {
            "x": 10201.27812,
            "y": 67.7,
            "z": 7997951,
            "name": "BG",
            "country": "Bulgaria"
          },
          {
            "x": 49406.29103,
            "y": 64.3,
            "z": 664610,
            "name": "BH",
            "country": "Bahrain"
          },
          {
            "x": 40518.17951,
            "y": 70,
            "z": 298045,
            "name": "BS",
            "country": "Bahamas"
          },
          {
            "x": 7114.552765,
            "y": 55.7,
            "z": 3751176,
            "name": "BA",
            "country": "Bosnia and Herzegovina"
          },
          {
            "x": 8053.173638,
            "y": 66.8,
            "z": 9871635,
            "name": "BY",
            "country": "Belarus"
          },
          {
            "x": 6599.339352,
            "y": 56.3,
            "z": 247310,
            "name": "BZ",
            "country": "Belize"
          },
          {
            "x": 5415.52606,
            "y": 63,
            "z": 8418270,
            "name": "BO",
            "country": "Bolivia"
          },
          {
            "x": 11600.94846,
            "y": 58.4,
            "z": 174790339,
            "name": "BR",
            "country": "Brazil"
          },
          {
            "x": 15124.43624,
            "y": 69,
            "z": 271511,
            "name": "BB",
            "country": "Barbados"
          },
          {
            "x": 69022.88016,
            "y": 64.3,
            "z": 333166,
            "name": "BN",
            "country": "Brunei Darussalam"
          },
          {
            "x": 4061.499026,
            "y": 0,
            "z": 591014,
            "name": "BT",
            "country": "Bhutan"
          },
          {
            "x": 11439.9084,
            "y": 58.9,
            "z": 1643333,
            "name": "BW",
            "country": "Botswana"
          },
          {
            "x": 1040.103835,
            "y": 24.3,
            "z": 3640421,
            "name": "CF",
            "country": "Central African Republic"
          },
          {
            "x": 37194.3956,
            "y": 80.5,
            "z": 30588379,
            "name": "CA",
            "country": "Canada"
          },
          {
            "x": 59389.42406,
            "y": 80.3,
            "z": 7143764,
            "name": "CH",
            "country": "Switzerland"
          },
          {
            "x": 15638.00094,
            "y": 66.1,
            "z": 15342350,
            "name": "CL",
            "country": "Chile"
          },
          {
            "x": 3451.679231,
            "y": 48.1,
            "z": 1290550767,
            "name": "CN",
            "country": "China"
          },
          {
            "x": 4093.874782,
            "y": 29.7,
            "z": 16454660,
            "name": "CI",
            "country": "Cote d'Ivoire"
          },
          {
            "x": 2750.511165,
            "y": 36.4,
            "z": 15513944,
            "name": "CM",
            "country": "Cameroon"
          },
          {
            "x": 751.5577568,
            "y": 30.5,
            "z": 47105830,
            "name": "CD",
            "country": "DR Congo"
          },
          {
            "x": 4402.901455,
            "y": 45.4,
            "z": 3127420,
            "name": "CG",
            "country": "Congo Republic"
          },
          {
            "x": 9042.662791,
            "y": 53.4,
            "z": 39629965,
            "name": "CO",
            "country": "Colombia"
          },
          {
            "x": 2833.591016,
            "y": 32.8,
            "z": 542358,
            "name": "KM",
            "country": "Comoros"
          },
          {
            "x": 4065.479414,
            "y": 43.6,
            "z": 428178,
            "name": "CV",
            "country": "Cabo Verde"
          },
          {
            "x": 12624.07057,
            "y": 59.3,
            "z": 3962369,
            "name": "CR",
            "country": "Costa Rica"
          },
          {
            "x": 33013.98251,
            "y": 67.6,
            "z": 943288,
            "name": "CY",
            "country": "Cyprus"
          },
          {
            "x": 24976.50632,
            "y": 74.1,
            "z": 10289374,
            "name": "CZ",
            "country": "Czech Republic"
          },
          {
            "x": 42864.93289,
            "y": 82.5,
            "z": 81400883,
            "name": "DE",
            "country": "Germany"
          },
          {
            "x": 0,
            "y": 18.8,
            "z": 717577,
            "name": "DJ",
            "country": "Djibouti"
          },
          {
            "x": 9611.53337,
            "y": 59.5,
            "z": 69650,
            "name": "DM",
            "country": "Dominica"
          },
          {
            "x": 48907.0114,
            "y": 80.9,
            "z": 5341192,
            "name": "DK",
            "country": "Denmark"
          },
          {
            "x": 9322.139196,
            "y": 55.4,
            "z": 8471317,
            "name": "DO",
            "country": "Dominican Republic"
          },
          {
            "x": 8710.455149,
            "y": 50,
            "z": 31042238,
            "name": "DZ",
            "country": "Algeria"
          },
          {
            "x": 8176.344448,
            "y": 57.7,
            "z": 12681123,
            "name": "EC",
            "country": "Ecuador"
          },
          {
            "x": 7744.715238,
            "y": 46.8,
            "z": 68831561,
            "name": "EG",
            "country": "Egypt"
          },
          {
            "x": 34757.61502,
            "y": 71.5,
            "z": 40824745,
            "name": "ES",
            "country": "Spain"
          },
          {
            "x": 17778.96558,
            "y": 80.8,
            "z": 1399111,
            "name": "EE",
            "country": "Estonia"
          },
          {
            "x": 727.7666847,
            "y": 16.9,
            "z": 66224808,
            "name": "ET",
            "country": "Ethiopia"
          },
          {
            "x": 39894.19446,
            "y": 80.3,
            "z": 5187953,
            "name": "FI",
            "country": "Finland"
          },
          {
            "x": 9575.878839,
            "y": 68.6,
            "z": 811011,
            "name": "FJ",
            "country": "Fiji"
          },
          {
            "x": 39732.28245,
            "y": 74.3,
            "z": 59015092,
            "name": "FR",
            "country": "France"
          },
          {
            "x": 3434.098093,
            "y": 44.1,
            "z": 107405,
            "name": "FM",
            "country": "Micronesia, Fed. Sts."
          },
          {
            "x": 16567.24561,
            "y": 54.5,
            "z": 1228359,
            "name": "GA",
            "country": "Gabon"
          },
          {
            "x": 38280.80027,
            "y": 83.6,
            "z": 58923305,
            "name": "GB",
            "country": "United Kingdom"
          },
          {
            "x": 4919.23188,
            "y": 71.7,
            "z": 4362184,
            "name": "GE",
            "country": "Georgia"
          },
          {
            "x": 2734.806763,
            "y": 42.7,
            "z": 19278850,
            "name": "GH",
            "country": "Ghana"
          },
          {
            "x": 1704.956378,
            "y": 19.1,
            "z": 8240735,
            "name": "GN",
            "country": "Guinea"
          },
          {
            "x": 2270.486495,
            "y": 25.4,
            "z": 1317708,
            "name": "GM",
            "country": "Gambia"
          },
          {
            "x": 1722.757481,
            "y": 0,
            "z": 1201305,
            "name": "GW",
            "country": "Guinea-Bissau"
          },
          {
            "x": 11176.51896,
            "y": 40.2,
            "z": 606180,
            "name": "GQ",
            "country": "Equatorial Guinea"
          },
          {
            "x": 29186.32455,
            "y": 67.2,
            "z": 11082103,
            "name": "GR",
            "country": "Greece"
          },
          {
            "x": 11613.41539,
            "y": 0,
            "z": 102837,
            "name": "GD",
            "country": "Grenada"
          },
          {
            "x": 6499.883286,
            "y": 35.8,
            "z": 11650744,
            "name": "GT",
            "country": "Guatemala"
          },
          {
            "x": 7776.308557,
            "y": 56.1,
            "z": 746718,
            "name": "GY",
            "country": "Guyana"
          },
          {
            "x": 36317.1207,
            "y": 68.6,
            "z": 6606328,
            "name": "HK",
            "country": "Hong Kong"
          },
          {
            "x": 4108.774977,
            "y": 41.8,
            "z": 6574510,
            "name": "HN",
            "country": "Honduras"
          },
          {
            "x": 18183.58811,
            "y": 65.6,
            "z": 4428075,
            "name": "HR",
            "country": "Croatia"
          },
          {
            "x": 2684.551926,
            "y": 34.5,
            "z": 8463802,
            "name": "HT",
            "country": "Haiti"
          },
          {
            "x": 19406.52134,
            "y": 73.6,
            "z": 10220509,
            "name": "HU",
            "country": "Hungary"
          },
          {
            "x": 5689.260223,
            "y": 51.8,
            "z": 211513822,
            "name": "ID",
            "country": "Indonesia"
          },
          {
            "x": 2578.59153,
            "y": 37.9,
            "z": 1056575548,
            "name": "IN",
            "country": "India"
          },
          {
            "x": 48628.45114,
            "y": 81.8,
            "z": 3783095,
            "name": "IE",
            "country": "Ireland"
          },
          {
            "x": 10066.80278,
            "y": 53,
            "z": 65623397,
            "name": "IR",
            "country": "Iran"
          },
          {
            "x": 9364.596705,
            "y": 41.1,
            "z": 23497589,
            "name": "IQ",
            "country": "Iraq"
          },
          {
            "x": 41530.51732,
            "y": 78.9,
            "z": 280439,
            "name": "IS",
            "country": "Iceland"
          },
          {
            "x": 31416.93851,
            "y": 82,
            "z": 5945949,
            "name": "IL",
            "country": "Israel"
          },
          {
            "x": 43053.93306,
            "y": 70,
            "z": 56692178,
            "name": "IT",
            "country": "Italy"
          },
          {
            "x": 9344.534643,
            "y": 54.8,
            "z": 2654698,
            "name": "JM",
            "country": "Jamaica"
          },
          {
            "x": 8741.72741,
            "y": 67.1,
            "z": 5122495,
            "name": "JO",
            "country": "Jordan"
          },
          {
            "x": 35611.80391,
            "y": 75.4,
            "z": 127524168,
            "name": "JP",
            "country": "Japan"
          },
          {
            "x": 10275.76187,
            "y": 69.2,
            "z": 14922724,
            "name": "KZ",
            "country": "Kazakhstan"
          },
          {
            "x": 2867.746708,
            "y": 40.7,
            "z": 31964557,
            "name": "KE",
            "country": "Kenya"
          },
          {
            "x": 3078.909252,
            "y": 65.7,
            "z": 4920712,
            "name": "KG",
            "country": "Kyrgyz Republic"
          },
          {
            "x": 1481.656828,
            "y": 31.9,
            "z": 12155241,
            "name": "KH",
            "country": "Cambodia"
          },
          {
            "x": 2183.675029,
            "y": 51.6,
            "z": 84405,
            "name": "KI",
            "country": "Kiribati"
          },
          {
            "x": 21459.73563,
            "y": 0,
            "z": 44083,
            "name": "KN",
            "country": "St. Kitts and Nevis"
          },
          {
            "x": 22963.63854,
            "y": 78.7,
            "z": 47379237,
            "name": "KR",
            "country": "South Korea"
          },
          {
            "x": 54984.95235,
            "y": 59.5,
            "z": 2045123,
            "name": "KW",
            "country": "Kuwait"
          },
          {
            "x": 2861.27184,
            "y": 35.2,
            "z": 5323701,
            "name": "LA",
            "country": "Laos"
          },
          {
            "x": 14361.68302,
            "y": 0,
            "z": 3842774,
            "name": "LB",
            "country": "Lebanon"
          },
          {
            "x": 1699.020836,
            "y": 40.8,
            "z": 2848447,
            "name": "LR",
            "country": "Liberia"
          },
          {
            "x": 16746.27387,
            "y": 62.1,
            "z": 5357893,
            "name": "LY",
            "country": "Libya"
          },
          {
            "x": 12963.85387,
            "y": 59.3,
            "z": 156737,
            "name": "LC",
            "country": "St. Lucia"
          },
          {
            "x": 5949.970029,
            "y": 67.9,
            "z": 18777606,
            "name": "LK",
            "country": "Sri Lanka"
          },
          {
            "x": 1685.367014,
            "y": 45,
            "z": 2032805,
            "name": "LS",
            "country": "Lesotho"
          },
          {
            "x": 13846.68329,
            "y": 75.8,
            "z": 3501842,
            "name": "LT",
            "country": "Lithuania"
          },
          {
            "x": 95901.0204,
            "y": 71.7,
            "z": 436106,
            "name": "LU",
            "country": "Luxembourg"
          },
          {
            "x": 12863.30935,
            "y": 70.7,
            "z": 2384150,
            "name": "LV",
            "country": "Latvia"
          },
          {
            "x": 4370.799491,
            "y": 34.9,
            "z": 28793672,
            "name": "MA",
            "country": "Morocco"
          },
          {
            "x": 5074.377064,
            "y": 61.7,
            "z": 4202659,
            "name": "MD",
            "country": "Moldova"
          },
          {
            "x": 1614.382282,
            "y": 39.9,
            "z": 15766806,
            "name": "MG",
            "country": "Madagascar"
          },
          {
            "x": 13358.58716,
            "y": 43,
            "z": 279396,
            "name": "MV",
            "country": "Maldives"
          },
          {
            "x": 17756.56647,
            "y": 54.4,
            "z": 98899845,
            "name": "MX",
            "country": "Mexico"
          },
          {
            "x": 3336.09316,
            "y": 0,
            "z": 50754,
            "name": "MH",
            "country": "Marshall Islands"
          },
          {
            "x": 10182.12607,
            "y": 54.4,
            "z": 2034823,
            "name": "MK",
            "country": "Macedonia"
          },
          {
            "x": 1627.732318,
            "y": 16.8,
            "z": 10946448,
            "name": "ML",
            "country": "Mali"
          },
          {
            "x": 27482.86907,
            "y": 64.8,
            "z": 393649,
            "name": "MT",
            "country": "Malta"
          },
          {
            "x": 1093.788207,
            "y": 31.9,
            "z": 46719698,
            "name": "MM",
            "country": "Myanmar"
          },
          {
            "x": 12418.99354,
            "y": 0,
            "z": 613558,
            "name": "ME",
            "country": "Montenegro"
          },
          {
            "x": 4528.955946,
            "y": 53.4,
            "z": 2397417,
            "name": "MN",
            "country": "Mongolia"
          },
          {
            "x": 630.7016136,
            "y": 23.6,
            "z": 17711925,
            "name": "MZ",
            "country": "Mozambique"
          },
          {
            "x": 4361.213513,
            "y": 27.9,
            "z": 2630217,
            "name": "MR",
            "country": "Mauritania"
          },
          {
            "x": 11890.58865,
            "y": 54.6,
            "z": 1185147,
            "name": "MU",
            "country": "Mauritius"
          },
          {
            "x": 1107.537894,
            "y": 37.8,
            "z": 11148751,
            "name": "MW",
            "country": "Malawi"
          },
          {
            "x": 15917.05717,
            "y": 61.9,
            "z": 23194252,
            "name": "MY",
            "country": "Malaysia"
          },
          {
            "x": 6804.866743,
            "y": 51,
            "z": 1794583,
            "name": "NA",
            "country": "Namibia"
          },
          {
            "x": 933.3463759,
            "y": 11.6,
            "z": 11331561,
            "name": "NE",
            "country": "Niger"
          },
          {
            "x": 2977.041475,
            "y": 0,
            "z": 122283853,
            "name": "NG",
            "country": "Nigeria"
          },
          {
            "x": 3968.892933,
            "y": 45.7,
            "z": 5069310,
            "name": "NI",
            "country": "Nicaragua"
          },
          {
            "x": 47422.2034,
            "y": 82.1,
            "z": 15926188,
            "name": "NL",
            "country": "Netherlands"
          },
          {
            "x": 57127.39975,
            "y": 88.8,
            "z": 4499375,
            "name": "NO",
            "country": "Norway"
          },
          {
            "x": 2077.652056,
            "y": 32.8,
            "z": 23941099,
            "name": "NP",
            "country": "Nepal"
          },
          {
            "x": 32837.09789,
            "y": 86.9,
            "z": 3858992,
            "name": "NZ",
            "country": "New Zealand"
          },
          {
            "x": 33839.52054,
            "y": 47.5,
            "z": 2267973,
            "name": "OM",
            "country": "Oman"
          },
          {
            "x": 3245.378342,
            "y": 25.9,
            "z": 142343583,
            "name": "PK",
            "country": "Pakistan"
          },
          {
            "x": 14507.79597,
            "y": 62.7,
            "z": 3030333,
            "name": "PA",
            "country": "Panama"
          },
          {
            "x": 6422.480568,
            "y": 63.6,
            "z": 26459944,
            "name": "PE",
            "country": "Peru"
          },
          {
            "x": 4453.756672,
            "y": 57.2,
            "z": 77991757,
            "name": "PH",
            "country": "Philippines"
          },
          {
            "x": 13586.80504,
            "y": 76.1,
            "z": 19104,
            "name": "PW",
            "country": "Palau"
          },
          {
            "x": 2871.416377,
            "y": 28.4,
            "z": 5847590,
            "name": "PG",
            "country": "Papua New Guinea"
          },
          {
            "x": 16257.64588,
            "y": 77.7,
            "z": 38556699,
            "name": "PL",
            "country": "Poland"
          },
          {
            "x": 30383.13782,
            "y": 66.1,
            "z": 10297117,
            "name": "PT",
            "country": "Portugal"
          },
          {
            "x": 8530.20799,
            "y": 52.4,
            "z": 5323202,
            "name": "PY",
            "country": "Paraguay"
          },
          {
            "x": 4503.248849,
            "y": 0,
            "z": 3224009,
            "name": "PS",
            "country": "Palestine"
          },
          {
            "x": 86566.30285,
            "y": 61.3,
            "z": 592467,
            "name": "QA",
            "country": "Qatar"
          },
          {
            "x": 12109.5524,
            "y": 65.4,
            "z": 22137423,
            "name": "RO",
            "country": "Romania"
          },
          {
            "x": 14569.93658,
            "y": 72.4,
            "z": 146404890,
            "name": "RU",
            "country": "Russia"
          },
          {
            "x": 867.6151907,
            "y": 27.6,
            "z": 7933688,
            "name": "RW",
            "country": "Rwanda"
          },
          {
            "x": 41955.20779,
            "y": 55.5,
            "z": 20663840,
            "name": "SA",
            "country": "Saudi Arabia"
          },
          {
            "x": 2109.560575,
            "y": 23.8,
            "z": 27275019,
            "name": "SD",
            "country": "Sudan"
          },
          {
            "x": 2595.109288,
            "y": 21.3,
            "z": 9797731,
            "name": "SN",
            "country": "Senegal"
          },
          {
            "x": 56106.73202,
            "y": 64.9,
            "z": 4028872,
            "name": "SG",
            "country": "Singapore"
          },
          {
            "x": 2253.610862,
            "y": 33.6,
            "z": 412665,
            "name": "SB",
            "country": "Solomon Islands"
          },
          {
            "x": 1063.297198,
            "y": 27,
            "z": 4584570,
            "name": "SL",
            "country": "Sierra Leone"
          },
          {
            "x": 6548.63137,
            "y": 49.3,
            "z": 5887930,
            "name": "SV",
            "country": "El Salvador"
          },
          {
            "x": 8900.593928,
            "y": 67.7,
            "z": 9487612,
            "name": "RS",
            "country": "Serbia"
          },
          {
            "x": 0,
            "y": 40.2,
            "z": 142264,
            "name": "ST",
            "country": "Sao Tome and Principe"
          },
          {
            "x": 13068.20615,
            "y": 0,
            "z": 470944,
            "name": "SR",
            "country": "Suriname"
          },
          {
            "x": 15660.64385,
            "y": 71.2,
            "z": 5399207,
            "name": "SK",
            "country": "Slovakia"
          },
          {
            "x": 26281.06845,
            "y": 79.5,
            "z": 1987710,
            "name": "SI",
            "country": "Slovenia"
          },
          {
            "x": 40625.36205,
            "y": 88.1,
            "z": 8881642,
            "name": "SE",
            "country": "Sweden"
          },
          {
            "x": 5579.136559,
            "y": 38.8,
            "z": 1005432,
            "name": "SZ",
            "country": "Eswatini"
          },
          {
            "x": 18931.15063,
            "y": 58.8,
            "z": 80998,
            "name": "SC",
            "country": "Seychelles"
          },
          {
            "x": 897.3470374,
            "y": 18,
            "z": 8355654,
            "name": "TD",
            "country": "Chad"
          },
          {
            "x": 1700.441397,
            "y": 39.5,
            "z": 4924406,
            "name": "TG",
            "country": "Togo"
          },
          {
            "x": 9809.62237,
            "y": 51.7,
            "z": 62952639,
            "name": "TH",
            "country": "Thailand"
          },
          {
            "x": 1324.90986,
            "y": 62.6,
            "z": 6216329,
            "name": "TJ",
            "country": "Tajikistan"
          },
          {
            "x": 4622.078757,
            "y": 0,
            "z": 4516128,
            "name": "TM",
            "country": "Turkmenistan"
          },
          {
            "x": 2328.304667,
            "y": 36.4,
            "z": 884366,
            "name": "TL",
            "country": "Timor-Leste"
          },
          {
            "x": 5034.415166,
            "y": 66.9,
            "z": 97962,
            "name": "TO",
            "country": "Tonga"
          },
          {
            "x": 16939.52547,
            "y": 63.6,
            "z": 1267159,
            "name": "TT",
            "country": "Trinidad and Tobago"
          },
          {
            "x": 7329.345126,
            "y": 52.6,
            "z": 9708347,
            "name": "TN",
            "country": "Tunisia"
          },
          {
            "x": 15433.58712,
            "y": 49.3,
            "z": 63240196,
            "name": "TR",
            "country": "Turkey"
          },
          {
            "x": 1409.453964,
            "y": 31.4,
            "z": 33499177,
            "name": "TZ",
            "country": "Tanzania"
          },
          {
            "x": 1252.752131,
            "y": 43,
            "z": 23650159,
            "name": "UG",
            "country": "Uganda"
          },
          {
            "x": 7221.465608,
            "y": 71.7,
            "z": 48838058,
            "name": "UA",
            "country": "Ukraine"
          },
          {
            "x": 14482.75455,
            "y": 66.1,
            "z": 3319734,
            "name": "UY",
            "country": "Uruguay"
          },
          {
            "x": 50124.89118,
            "y": 84.5,
            "z": 281710914,
            "name": "US",
            "country": "United States"
          },
          {
            "x": 2786.430374,
            "y": 60.1,
            "z": 24769955,
            "name": "UZ",
            "country": "Uzbekistan"
          },
          {
            "x": 8646.608816,
            "y": 60.6,
            "z": 107787,
            "name": "VC",
            "country": "St. Vincent and the Grenadines"
          },
          {
            "x": 2954.982905,
            "y": 47.4,
            "z": 79910411,
            "name": "VN",
            "country": "Vietnam"
          },
          {
            "x": 3068.095866,
            "y": 0,
            "z": 184964,
            "name": "VU",
            "country": "Vanuatu"
          },
          {
            "x": 4809.239885,
            "y": 62.7,
            "z": 174454,
            "name": "WS",
            "country": "Samoa"
          },
          {
            "x": 10088.85225,
            "y": 65.2,
            "z": 44967713,
            "name": "ZA",
            "country": "South Africa"
          },
          {
            "x": 1990.858991,
            "y": 46.8,
            "z": 10415942,
            "name": "ZM",
            "country": "Zambia"
          },
          {
            "x": 3756.139483,
            "y": 48.8,
            "z": 11881482,
            "name": "ZW",
            "country": "Zimbabwe"
          }
         ]
    }]

});
