Highcharts.chart('container', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Average Food Security 2012 - 2021'
    },
    subtitle: {
        text: 'Source: <a href="https://impact.economist.com/sustainability/project/food-security-index/">Food Security: Economist</a>'
    },
    xAxis: {
        type: 'category',
        labels: {
            rotation: -45,
            style: {
                fontSize: '13px',
                fontFamily: 'Verdana, sans-serif'
            }
        }
    },
    yAxis: {
        min: 0,
        max: 100,
        title: {
            text: 'Food Secure %'
        }
    },
    legend: {
        enabled: false
    },
    tooltip: {
        pointFormat: 'Food Secure: <b>{point.y:.1f} %</b>'
    },
    series: [{
        color: '#FF0000',
        name: 'Population',
        data: [
            [2012,57.1840708  ],
            [2013,58.06902655  ],
            [2014,59.21769912  ],
            [2015,60.10088496  ],
            [2016,60.40619469  ],
            [2017,60.69026549  ],
            [2018,61.03628319  ],
            [2019,61.59734513  ],
            [2020,61.10353982  ],
            [2021,60.9  ]
          ],
        dataLabels: {
            enabled: true,
            rotation: -90,
            color: '#FFFFFF',
            align: 'right',
            format: '{point.y:.1f}', // one decimal
            y: 10, // 10 pixels down from the top
            style: {
                fontSize: '13px',
                fontFamily: 'Verdana, sans-serif'
            }
        }
    }]
});