$(function gdp() {
	var year = 2014;
	var start = 1990;
	var finish = 2019;
	var seriesPath = 'https://whfitzmaurice.github.io/visproject/education.json'

	// fetch data from json
	//fetch('https://whfitzmaurice.github.io/visproject/alljson.json')
		//.then(response => response.json())
		//.then((data) => {
		//	seriesPath = data;
		//	drawMap(0, [seriesPath[0]]);
		//})
		//.catch((e) => e);


	localStorageTest();
	clearStorage();

	addMapMenuItems(start, finish);
	getMapSeries(year, seriesPath);


	function prepMapData(year){
		// Prepare data for the selected year and return it

		var allData = getObject('allData');
		var selectedData = [];
		// OECD series runs from 1980 =>

		for (var i=0; i<allData.length; i++){
			// need to generate: {"iso-a3": "xxx", "value": nnnnn}
			selectedData.push({"iso-a3":allData[i][0].iso3, "value":allData[i][0].data[year-1990]});
			//console.log({"iso-a3":allData[i][0].iso3, "value":allData[i][0].data[year-1980]});
		};
		//console.log(JSON.stringify(selectedData));
		return selectedData;
	};

	function drawMap(year, selectedData){
		// draw a single chart
		$('#displayarea2').highcharts('Map', {

			title: {
				text: 'Education Index '+year
			},

			subtitle: {
				text: 'Source map: <a href="https://code.highcharts.com/mapdata/custom/world-robinson.js">World, Robinson projection, medium resolution</a>'
			},

			mapNavigation: {
				enabled: true,
				buttonOptions: {
					verticalAlign: 'bottom'
				}
			},
			
			colorAxis: {
				min: 0,
				//max: 10000000000000, // set to give a consistent scale - can be removed to emphasise between-country differences
				minColor: '#E6E6FF',
				maxColor: '#3333FF',
			},

			series: [{
				data: selectedData,
				mapData: Highcharts.maps['custom/world-robinson'],
				joinBy: 'iso-a3',
				name: 'Percentage educated '+year,
				states: {
					hover: {
						color: 'palegreen'
					}
				},
				dataLabels: {
					enabled: false,
					format: '{point.name}'
				}
			}]
		});
	};

	function addMapMenuItems(start, finish){
		// populate the menu
		var startTag = '<input type="radio" name="selectYear"';
		var endTag = '</input>';
		$('#menubox2').empty();
		$('#menubox2').append('<h3>Year to display</h3>');
		$('#menubox2').append('<button type="button" id="yearListSelect">Display</button>');
		$('#menubox2').append('<br />');
	
		// add a listener to respond to a button click
		$('#yearListSelect').on( 'click', function() {
			$('#displayarea2').empty();
			var year = $('input[name="selectYear"]:checked').val();
			//console.log('84', year)
			selectedData = prepMapData(year);
			drawMap(year, selectedData);
		});
	
		// make a list of buttons in two columns
		for (i=start; i<=finish; i++){
			if (i%2){
				var button = startTag+'value="'+i+'">'+i+endTag+'<br />';
			} else {
				var button = startTag+'value="'+i+'">'+i+endTag;
			};
			$('#menubox2').append(button);
		};
	};

	function getMapSeries(year, seriesPath){
		// fetch the series data from the server or a local file
		//	and store it in local storage
		//console.log('getting series '+seriesPath);
		$.getJSON(seriesPath, function (data) {
			//console.log(seriesPath, JSON.stringify(data));
			clearObject('allData');
			setObject('allData', data);
			drawMap(year, prepMapData(year));
		})
		.fail(function(jqXHR, textStatus, errorThrown) { 
			console.log('getJSON request failed! ' + textStatus); 
		});	
	};
	


	// button function
	

let optsWrapper = document.getElementById('options-wrapper').children; //buttons
	optsWrapper[0].classList.add('btn-active'); // may have to add to CSS / default selected

	for (let i = 0; i < optsWrapper.length; i++) {
		optsWrapper[i].addEventListener('click', (e) => {
			// toggle charts
			gdp(e.target.num || 0);
		});
	}
});