Highcharts.chart('container', {
    chart: {
        zoomType: 'x'
    },
    title: {
        text: 'Average Education Index Value 1990 - 2019'
    },
    subtitle: {
        text: 'Source: <a href="https://hdr.undp.org/en/indicators/103706">Education: UNDP</a>'
    },
    xAxis: {
        type: 'year'
    },
    yAxis: {
        min: 30,
        max: 70,
        tickInterval: 2,
        title: {
            text: 'Education Index Value'
        }
    },
    legend: {
        enabled: false
    },
    plotOptions: {
        line: {
            fillColor: '#3333FF',
            marker: {
                radius: 5
            },
            lineWidth: 3,
            states: {
                hover: {
                    lineWidth: 3
                }
            },
            threshold: null
        }
    },

    series: [{
        type: '',
        color: '#3333FF',
        name: 'Education Index Value',
        data: [
            [1990,36.53544974  ],
            [1991,37.04074074  ],
            [1992,37.5010582  ],
            [1993,38.11481481  ],
            [1994,38.76560847  ],
            [1995,40.35820106  ],
            [1996,41.0005291  ],
            [1997,41.57354497  ],
            [1998,42.26349206  ],
            [1999,43.48730159  ],
            [2000,50.16296296  ],
            [2001,50.96349206  ],
            [2002,52.03333333  ],
            [2003,53.36984127  ],
            [2004,54.74867725  ],
            [2005,57.1957672  ],
            [2006,57.97724868  ],
            [2007,58.72328042  ],
            [2008,59.56137566  ],
            [2009,60.22751323  ],
            [2010,61.33280423  ],
            [2011,62.03333333  ],
            [2012,62.6042328  ],
            [2013,63.23280423  ],
            [2014,63.75767196  ],
            [2015,64.22116402  ],
            [2016,64.57513228  ],
            [2017,65.28730159  ],
            [2018,65.51375661  ],
            [2019,65.91904762  ]
          ]
    }]
});
